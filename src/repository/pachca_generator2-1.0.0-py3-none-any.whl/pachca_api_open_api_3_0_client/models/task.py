import datetime
from typing import TYPE_CHECKING, Any, TypeVar, Union, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.base_task_kind import BaseTaskKind
from ..models.base_task_priority import BaseTaskPriority
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.base_custom_properties import BaseCustomProperties


T = TypeVar("T", bound="Task")


@_attrs_define
class Task:
    """
    Attributes:
        kind (BaseTaskKind): Тип напоминания
        content (str): Описание напоминания
        due_at (datetime.datetime): Срок выполнения напоминания (ISO-8601)
        priority (Union[Unset, BaseTaskPriority]): Приоритет (1 - по умолчанию, 2 - важно, 3 - очень важно)
        performer_ids (Union[Unset, list[int]]): Массив идентификаторов пользователей
        custom_properties (Union[Unset, list['BaseCustomProperties']]):
        id (Union[Unset, int]): Идентификатор созданного напоминания
        user_id (Union[Unset, int]): Идентификатор пользователя-создателя
        status (Union[Unset, str]): Статус напоминания
        created_at (Union[Unset, datetime.datetime]): Дата и время создания
    """

    kind: BaseTaskKind
    content: str
    due_at: datetime.datetime
    priority: Union[Unset, BaseTaskPriority] = UNSET
    performer_ids: Union[Unset, list[int]] = UNSET
    custom_properties: Union[Unset, list["BaseCustomProperties"]] = UNSET
    id: Union[Unset, int] = UNSET
    user_id: Union[Unset, int] = UNSET
    status: Union[Unset, str] = UNSET
    created_at: Union[Unset, datetime.datetime] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        kind = self.kind.value

        content = self.content

        due_at = self.due_at.isoformat()

        priority: Union[Unset, int] = UNSET
        if not isinstance(self.priority, Unset):
            priority = self.priority.value

        performer_ids: Union[Unset, list[int]] = UNSET
        if not isinstance(self.performer_ids, Unset):
            performer_ids = self.performer_ids

        custom_properties: Union[Unset, list[dict[str, Any]]] = UNSET
        if not isinstance(self.custom_properties, Unset):
            custom_properties = []
            for custom_properties_item_data in self.custom_properties:
                custom_properties_item = custom_properties_item_data.to_dict()
                custom_properties.append(custom_properties_item)

        id = self.id

        user_id = self.user_id

        status = self.status

        created_at: Union[Unset, str] = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "kind": kind,
                "content": content,
                "due_at": due_at,
            }
        )
        if priority is not UNSET:
            field_dict["priority"] = priority
        if performer_ids is not UNSET:
            field_dict["performer_ids"] = performer_ids
        if custom_properties is not UNSET:
            field_dict["custom_properties"] = custom_properties
        if id is not UNSET:
            field_dict["id"] = id
        if user_id is not UNSET:
            field_dict["user_id"] = user_id
        if status is not UNSET:
            field_dict["status"] = status
        if created_at is not UNSET:
            field_dict["created_at"] = created_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: dict[str, Any]) -> T:
        from ..models.base_custom_properties import BaseCustomProperties

        d = src_dict.copy()
        kind = BaseTaskKind(d.pop("kind"))

        content = d.pop("content")

        due_at = isoparse(d.pop("due_at"))

        _priority = d.pop("priority", UNSET)
        priority: Union[Unset, BaseTaskPriority]
        if isinstance(_priority, Unset):
            priority = UNSET
        else:
            priority = BaseTaskPriority(_priority)

        performer_ids = cast(list[int], d.pop("performer_ids", UNSET))

        custom_properties = []
        _custom_properties = d.pop("custom_properties", UNSET)
        for custom_properties_item_data in _custom_properties or []:
            custom_properties_item = BaseCustomProperties.from_dict(custom_properties_item_data)

            custom_properties.append(custom_properties_item)

        id = d.pop("id", UNSET)

        user_id = d.pop("user_id", UNSET)

        status = d.pop("status", UNSET)

        _created_at = d.pop("created_at", UNSET)
        created_at: Union[Unset, datetime.datetime]
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        task = cls(
            kind=kind,
            content=content,
            due_at=due_at,
            priority=priority,
            performer_ids=performer_ids,
            custom_properties=custom_properties,
            id=id,
            user_id=user_id,
            status=status,
            created_at=created_at,
        )

        task.additional_properties = d
        return task

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
