import datetime
from typing import TYPE_CHECKING, Any, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.message_entity_type import MessageEntityType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.message_files_item import MessageFilesItem


T = TypeVar("T", bound="Message")


@_attrs_define
class Message:
    """
    Attributes:
        entity_type (Union[Unset, MessageEntityType]):  Default: MessageEntityType.DISCUSSION.
        entity_id (Union[Unset, int]):
        content (Union[Unset, str]):
        id (Union[Unset, int]):
        chat_id (Union[Unset, int]):
        user_id (Union[Unset, int]):
        created_at (Union[Unset, datetime.datetime]):
        files (Union[Unset, list['MessageFilesItem']]):
    """

    entity_type: Union[Unset, MessageEntityType] = MessageEntityType.DISCUSSION
    entity_id: Union[Unset, int] = UNSET
    content: Union[Unset, str] = UNSET
    id: Union[Unset, int] = UNSET
    chat_id: Union[Unset, int] = UNSET
    user_id: Union[Unset, int] = UNSET
    created_at: Union[Unset, datetime.datetime] = UNSET
    files: Union[Unset, list["MessageFilesItem"]] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        entity_type: Union[Unset, str] = UNSET
        if not isinstance(self.entity_type, Unset):
            entity_type = self.entity_type.value

        entity_id = self.entity_id

        content = self.content

        id = self.id

        chat_id = self.chat_id

        user_id = self.user_id

        created_at: Union[Unset, str] = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        files: Union[Unset, list[dict[str, Any]]] = UNSET
        if not isinstance(self.files, Unset):
            files = []
            for files_item_data in self.files:
                files_item = files_item_data.to_dict()
                files.append(files_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if entity_type is not UNSET:
            field_dict["entity_type"] = entity_type
        if entity_id is not UNSET:
            field_dict["entity_id"] = entity_id
        if content is not UNSET:
            field_dict["content"] = content
        if id is not UNSET:
            field_dict["id"] = id
        if chat_id is not UNSET:
            field_dict["chat_id"] = chat_id
        if user_id is not UNSET:
            field_dict["user_id"] = user_id
        if created_at is not UNSET:
            field_dict["created_at"] = created_at
        if files is not UNSET:
            field_dict["files"] = files

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: dict[str, Any]) -> T:
        from ..models.message_files_item import MessageFilesItem

        d = src_dict.copy()
        _entity_type = d.pop("entity_type", UNSET)
        entity_type: Union[Unset, MessageEntityType]
        if isinstance(_entity_type, Unset):
            entity_type = UNSET
        else:
            entity_type = MessageEntityType(_entity_type)

        entity_id = d.pop("entity_id", UNSET)

        content = d.pop("content", UNSET)

        id = d.pop("id", UNSET)

        chat_id = d.pop("chat_id", UNSET)

        user_id = d.pop("user_id", UNSET)

        _created_at = d.pop("created_at", UNSET)
        created_at: Union[Unset, datetime.datetime]
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        files = []
        _files = d.pop("files", UNSET)
        for files_item_data in _files or []:
            files_item = MessageFilesItem.from_dict(files_item_data)

            files.append(files_item)

        message = cls(
            entity_type=entity_type,
            entity_id=entity_id,
            content=content,
            id=id,
            chat_id=chat_id,
            user_id=user_id,
            created_at=created_at,
            files=files,
        )

        message.additional_properties = d
        return message

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
