from enum import Enum


class BaseEmployeeInviteStatus(str, Enum):
    CONFIRMED = "confirmed"
    SENT = "sent"

    def __str__(self) -> str:
        return str(self.value)
