from http import HTTPStatus
from typing import Any, Optional, Union

import Errors.from_dict
import httpx

from ...models.errors import Errors
from ...models.get_tag_response_200 import GetTagResponse200
from ...types import Response


def _get_kwargs_getTag(
    self,
    id: int,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": f"/group_tags/{id}",
    }

    self.logger.debug("Создание параметров getTag.")
    return _kwargs


def _parse_response_getTag(self, response: httpx.Response) -> Optional[Union[Errors, GetTagResponse200]]:
    self.logger.info(f"Получен ответ с кодом: {response.status_code} для getTag")
    if response.status_code == 200:
        response_200 = GetTagResponse200.from_dict(response.json())

        return response_200
    self.logger.info(f"Получен ответ с кодом: {response.status_code} для getTag")
    if response.status_code == 400:
        response_400 = Errors.from_dict(response.json())

        return response_400
    else:
        response_error = Errors.from_dict(response.json())
        return response_error


def _build_response_getTag(self, response: httpx.Response) -> Response[Union[Errors, GetTagResponse200]]:
    self.logger.debug("Преобразование JSON в Python для getTag.")
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=self._parse_response_getTag(response=response),
    )


async def getTag(
    self,
    id: int,
) -> Optional[Union[Errors, GetTagResponse200]]:
    """получение информации о теге

     Метод для получения информации о теге. Названия тегов являются уникальными в компании.

    Для получения тега вам необходимо знать его id и указать его в URL запроса. Параметры запроса
    отсутствуют

    Args:
        id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Errors, GetTagResponse200]
    """

    self.logger.info("Начинаем создание ответа на запрос.")

    kwargs = self._get_kwargs_getTag(
        id=id,
    )

    response = await self.client.get_async_httpx_client().request(**kwargs)

    return self._build_response_getTag(response=response).parsed
