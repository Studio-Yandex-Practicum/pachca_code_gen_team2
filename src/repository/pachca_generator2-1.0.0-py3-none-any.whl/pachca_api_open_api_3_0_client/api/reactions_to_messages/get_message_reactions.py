from http import HTTPStatus
from typing import Any, Optional, Union

import Errors.from_dict
import httpx

from ...models.errors import Errors
from ...models.get_message_reactions_response_200 import GetMessageReactionsResponse200
from ...types import UNSET, Response, Unset


def _get_kwargs_getMessageReactions(
    self,
    id: int,
    per: Union[Unset, int] = 50,
    page: Union[Unset, int] = 1,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    params["per"] = per

    params["page"] = page

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": f"/messages/{id}/reactions",
        "params": params,
    }

    self.logger.debug("Создание параметров getMessageReactions.")
    return _kwargs


def _parse_response_getMessageReactions(
    self, response: httpx.Response
) -> Optional[Union[Errors, GetMessageReactionsResponse200]]:
    self.logger.info(f"Получен ответ с кодом: {response.status_code} для getMessageReactions")
    if response.status_code == 200:
        response_200 = GetMessageReactionsResponse200.from_dict(response.json())

        return response_200
    self.logger.info(f"Получен ответ с кодом: {response.status_code} для getMessageReactions")
    if response.status_code == 400:
        response_400 = Errors.from_dict(response.json())

        return response_400
    else:
        response_error = Errors.from_dict(response.json())
        return response_error


def _build_response_getMessageReactions(
    self, response: httpx.Response
) -> Response[Union[Errors, GetMessageReactionsResponse200]]:
    self.logger.debug("Преобразование JSON в Python для getMessageReactions.")
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=self._parse_response_getMessageReactions(response=response),
    )


async def getMessageReactions(
    self,
    id: int,
    per: Union[Unset, int] = 50,
    page: Union[Unset, int] = 1,
) -> Optional[Union[Errors, GetMessageReactionsResponse200]]:
    """получение актуального списка реакций

     Метод для получения актуального списка реакций на сообщение.

    Идентификатор сообщения, список реакций на которое необходимо получить, передается в URL (например,
    /messages/7231942/reactions). Количество возвращаемых сущностей и страница выборки указываются в
    теле запроса

    Args:
        id (int):
        per (Union[Unset, int]):  Default: 50.
        page (Union[Unset, int]):  Default: 1.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Errors, GetMessageReactionsResponse200]
    """

    self.logger.info("Начинаем создание ответа на запрос.")

    kwargs = self._get_kwargs_getMessageReactions(
        id=id,
        per=per,
        page=page,
    )

    response = await self.client.get_async_httpx_client().request(**kwargs)

    return self._build_response_getMessageReactions(response=response).parsed
