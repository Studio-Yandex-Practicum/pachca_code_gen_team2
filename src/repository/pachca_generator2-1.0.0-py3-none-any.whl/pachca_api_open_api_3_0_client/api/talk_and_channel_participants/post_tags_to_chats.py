from http import HTTPStatus
from typing import Any, Optional, Union, cast

import Errors.from_dict
import httpx

from ...models.errors import Errors
from ...models.group_tag import GroupTag
from ...types import Response


def _get_kwargs_postTagsToChats(
    self,
    id: int,
    body: GroupTag,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": f"/chats/{id}/group_tags",
    }

    _body = body.to_dict()

    _kwargs["json"] = _body
    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    self.logger.debug("Создание параметров postTagsToChats.")
    return _kwargs


def _parse_response_postTagsToChats(self, response: httpx.Response) -> Optional[Union[Any, Errors]]:
    self.logger.info(f"Получен ответ с кодом: {response.status_code} для postTagsToChats")
    if response.status_code == 201:
        response_201 = cast(Any, None)
        return response_201
    self.logger.info(f"Получен ответ с кодом: {response.status_code} для postTagsToChats")
    if response.status_code == 400:
        response_400 = Errors.from_dict(response.json())

        return response_400
    self.logger.info(f"Получен ответ с кодом: {response.status_code} для postTagsToChats")
    if response.status_code == 422:
        response_422 = Errors.from_dict(response.json())

        return response_422
    else:
        response_error = Errors.from_dict(response.json())
        return response_error


def _build_response_postTagsToChats(self, response: httpx.Response) -> Response[Union[Any, Errors]]:
    self.logger.debug("Преобразование JSON в Python для postTagsToChats.")
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=self._parse_response_postTagsToChats(response=response),
    )


async def postTagsToChats(
    self,
    id: int,
    body: GroupTag,
) -> Optional[Union[Any, Errors]]:
    """добавление тегов в состав участников беседы или канала

     Метод для добавления тегов в состав участников беседы или канала.

    Args:
        id (int):  Example: 533.
        body (GroupTag):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, Errors]
    """

    self.logger.info("Начинаем создание ответа на запрос.")

    kwargs = self._get_kwargs_postTagsToChats(
        id=id,
        body=body,
    )

    response = await self.client.get_async_httpx_client().request(**kwargs)

    return self._build_response_postTagsToChats(response=response).parsed
