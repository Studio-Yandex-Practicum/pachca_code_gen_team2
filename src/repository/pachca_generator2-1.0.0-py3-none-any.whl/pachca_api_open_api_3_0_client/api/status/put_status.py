from http import HTTPStatus
from typing import Any, Optional, Union

import Errors.from_dict
import httpx

from ...models.errors import Errors
from ...models.put_status_body import PutStatusBody
from ...models.put_status_response_200 import PutStatusResponse200
from ...types import Response


def _get_kwargs_putStatus(
    self,
    body: PutStatusBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/profile/status",
    }

    _body = body.to_dict()

    _kwargs["json"] = _body
    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    self.logger.debug("Создание параметров putStatus.")
    return _kwargs


def _parse_response_putStatus(self, response: httpx.Response) -> Optional[Union[Errors, PutStatusResponse200]]:
    self.logger.info(f"Получен ответ с кодом: {response.status_code} для putStatus")
    if response.status_code == 200:
        response_200 = PutStatusResponse200.from_dict(response.json())

        return response_200
    self.logger.info(f"Получен ответ с кодом: {response.status_code} для putStatus")
    if response.status_code == 400:
        response_400 = Errors.from_dict(response.json())

        return response_400
    else:
        response_error = Errors.from_dict(response.json())
        return response_error


def _build_response_putStatus(self, response: httpx.Response) -> Response[Union[Errors, PutStatusResponse200]]:
    self.logger.debug("Преобразование JSON в Python для putStatus.")
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=self._parse_response_putStatus(response=response),
    )


async def putStatus(
    self,
    body: PutStatusBody,
) -> Optional[Union[Errors, PutStatusResponse200]]:
    """новый статус

     Метод для установки себе нового статуса.

    Args:
        body (PutStatusBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Errors, PutStatusResponse200]
    """

    self.logger.info("Начинаем создание ответа на запрос.")

    kwargs = self._get_kwargs_putStatus(
        body=body,
    )

    response = await self.client.get_async_httpx_client().request(**kwargs)

    return self._build_response_putStatus(response=response).parsed
