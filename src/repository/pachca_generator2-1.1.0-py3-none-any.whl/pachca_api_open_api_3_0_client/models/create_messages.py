from typing import TYPE_CHECKING, Any, TypeVar, Union, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.base_messages_entity_type import BaseMessagesEntityType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.button import Button
    from ..models.create_edit_files_item import CreateEditFilesItem


T = TypeVar("T", bound="CreateMessages")


@_attrs_define
class CreateMessages:
    """
    Attributes:
        content (str): Текст сообщения Default: 'Текст сообщения'.
        entity_id (int):
        buttons (Union[Unset, list[list['Button']]]):
        entity_type (Union[Unset, BaseMessagesEntityType]):  Default: BaseMessagesEntityType.DISCUSSION.
        parent_message_id (Union[None, Unset, int]): Идентификатор сообщения, к которому написан ответ. Возвращается как
            null, если сообщение не является ответом.
        files (Union[Unset, list['CreateEditFilesItem']]):
        skip_invite_mentions (Union[Unset, bool]):  Default: False.
        link_preview (Union[Unset, bool]):  Default: False.
    """

    entity_id: int
    content: str = "Текст сообщения"
    buttons: Union[Unset, list[list["Button"]]] = UNSET
    entity_type: Union[Unset, BaseMessagesEntityType] = BaseMessagesEntityType.DISCUSSION
    parent_message_id: Union[None, Unset, int] = UNSET
    files: Union[Unset, list["CreateEditFilesItem"]] = UNSET
    skip_invite_mentions: Union[Unset, bool] = False
    link_preview: Union[Unset, bool] = False
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        content = self.content

        entity_id = self.entity_id

        buttons: Union[Unset, list[list[dict[str, Any]]]] = UNSET
        if not isinstance(self.buttons, Unset):
            buttons = []
            for componentsschemas_buttons_item_data in self.buttons:
                componentsschemas_buttons_item = []
                for componentsschemas_buttons_item_item_data in componentsschemas_buttons_item_data:
                    componentsschemas_buttons_item_item = componentsschemas_buttons_item_item_data.to_dict()
                    componentsschemas_buttons_item.append(componentsschemas_buttons_item_item)

                buttons.append(componentsschemas_buttons_item)

        entity_type: Union[Unset, str] = UNSET
        if not isinstance(self.entity_type, Unset):
            entity_type = self.entity_type.value

        parent_message_id: Union[None, Unset, int]
        if isinstance(self.parent_message_id, Unset):
            parent_message_id = UNSET
        else:
            parent_message_id = self.parent_message_id

        files: Union[Unset, list[dict[str, Any]]] = UNSET
        if not isinstance(self.files, Unset):
            files = []
            for componentsschemas_create_edit_files_item_data in self.files:
                componentsschemas_create_edit_files_item = componentsschemas_create_edit_files_item_data.to_dict()
                files.append(componentsschemas_create_edit_files_item)

        skip_invite_mentions = self.skip_invite_mentions

        link_preview = self.link_preview

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "content": content,
                "entity_id": entity_id,
            }
        )
        if buttons is not UNSET:
            field_dict["buttons"] = buttons
        if entity_type is not UNSET:
            field_dict["entity_type"] = entity_type
        if parent_message_id is not UNSET:
            field_dict["parent_message_id"] = parent_message_id
        if files is not UNSET:
            field_dict["files"] = files
        if skip_invite_mentions is not UNSET:
            field_dict["skip_invite_mentions"] = skip_invite_mentions
        if link_preview is not UNSET:
            field_dict["link_preview"] = link_preview

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: dict[str, Any]) -> T:
        from ..models.button import Button
        from ..models.create_edit_files_item import CreateEditFilesItem

        d = src_dict.copy()
        content = d.pop("content")

        entity_id = d.pop("entity_id")

        buttons = []
        _buttons = d.pop("buttons", UNSET)
        for componentsschemas_buttons_item_data in _buttons or []:
            componentsschemas_buttons_item = []
            _componentsschemas_buttons_item = componentsschemas_buttons_item_data
            for componentsschemas_buttons_item_item_data in _componentsschemas_buttons_item:
                componentsschemas_buttons_item_item = Button.from_dict(componentsschemas_buttons_item_item_data)

                componentsschemas_buttons_item.append(componentsschemas_buttons_item_item)

            buttons.append(componentsschemas_buttons_item)

        _entity_type = d.pop("entity_type", UNSET)
        entity_type: Union[Unset, BaseMessagesEntityType]
        if isinstance(_entity_type, Unset):
            entity_type = UNSET
        else:
            entity_type = BaseMessagesEntityType(_entity_type)

        def _parse_parent_message_id(data: object) -> Union[None, Unset, int]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, int], data)

        parent_message_id = _parse_parent_message_id(d.pop("parent_message_id", UNSET))

        files = []
        _files = d.pop("files", UNSET)
        for componentsschemas_create_edit_files_item_data in _files or []:
            componentsschemas_create_edit_files_item = CreateEditFilesItem.from_dict(
                componentsschemas_create_edit_files_item_data
            )

            files.append(componentsschemas_create_edit_files_item)

        skip_invite_mentions = d.pop("skip_invite_mentions", UNSET)

        link_preview = d.pop("link_preview", UNSET)

        create_messages = cls(
            content=content,
            entity_id=entity_id,
            buttons=buttons,
            entity_type=entity_type,
            parent_message_id=parent_message_id,
            files=files,
            skip_invite_mentions=skip_invite_mentions,
            link_preview=link_preview,
        )

        create_messages.additional_properties = d
        return create_messages

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
