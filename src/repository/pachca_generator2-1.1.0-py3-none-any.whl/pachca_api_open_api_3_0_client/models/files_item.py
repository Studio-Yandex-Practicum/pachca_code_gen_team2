from typing import Any, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.base_files_file_type import BaseFilesFileType
from ..types import UNSET, Unset

T = TypeVar("T", bound="FilesItem")


@_attrs_define
class FilesItem:
    """
    Attributes:
        key (str): Путь к файлу, полученный в результате загрузки файла (каждый файл в каждом сообщении должен иметь
            свой уникальный key, не допускается использование одного и того же key в разных сообщениях)
        name (str): Название файла, которое вы хотите отображать пользователю (рекомендуется писать вместе с
            расширением)
        file_type (BaseFilesFileType):
        id (Union[Unset, int]): Идентификатор поля
        url (Union[Unset, str]): Прямая временная ссылка на скачивание файла
    """

    key: str
    name: str
    file_type: BaseFilesFileType
    id: Union[Unset, int] = UNSET
    url: Union[Unset, str] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        key = self.key

        name = self.name

        file_type = self.file_type.value

        id = self.id

        url = self.url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "key": key,
                "name": name,
                "file_type": file_type,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if url is not UNSET:
            field_dict["url"] = url

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: dict[str, Any]) -> T:
        d = src_dict.copy()
        key = d.pop("key")

        name = d.pop("name")

        file_type = BaseFilesFileType(d.pop("file_type"))

        id = d.pop("id", UNSET)

        url = d.pop("url", UNSET)

        files_item = cls(
            key=key,
            name=name,
            file_type=file_type,
            id=id,
            url=url,
        )

        files_item.additional_properties = d
        return files_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
