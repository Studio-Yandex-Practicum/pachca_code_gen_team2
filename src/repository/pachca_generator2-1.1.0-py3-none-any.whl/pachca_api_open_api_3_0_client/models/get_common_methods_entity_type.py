from enum import Enum


class GetCommonMethodsEntityType(str, Enum):
    TASK = "Task"
    USER = "User"

    def __str__(self) -> str:
        return str(self.value)
