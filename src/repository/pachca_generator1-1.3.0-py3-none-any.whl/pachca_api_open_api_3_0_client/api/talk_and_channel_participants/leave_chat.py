from http import HTTPStatus
from typing import Any, Optional, Union, cast

import httpx

from ... import errors
from ...models.leave_chat_response_400 import LeaveChatResponse400
from ...types import Response


def _get_kwargs_leaveChat(
    self,
    id: int,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": f"/chats/{id}/leave",
    }

    return _kwargs


def _parse_response_leaveChat(self, response: httpx.Response) -> Optional[Union[Any, LeaveChatResponse400]]:
    if response.status_code == 200:
        response_200 = cast(Any, None)
        return response_200
    if response.status_code == 400:
        response_400 = LeaveChatResponse400.from_dict(response.json())

        return response_400
    if self.client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response_leaveChat(self, response: httpx.Response) -> Response[Union[Any, LeaveChatResponse400]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=self._parse_response_leaveChat(response=response),
    )


async def leaveChat(
    self,
    id: int,
) -> Optional[Union[Any, LeaveChatResponse400]]:
    """выход из беседы или канала

     Метод для самостоятельного выхода из беседы или канала. Параметры запроса отсутствуют/

    Args:
        id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, LeaveChatResponse400]
    """

    kwargs = self._get_kwargs_leaveChat(
        id=id,
    )

    response = await self.client.get_async_httpx_client().request(**kwargs)

    return self._build_response_leaveChat(response=response).parsed
