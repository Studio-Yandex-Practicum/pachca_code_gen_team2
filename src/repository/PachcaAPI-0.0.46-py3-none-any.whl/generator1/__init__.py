from generator1.generator import BASE_DIR  # noqa
