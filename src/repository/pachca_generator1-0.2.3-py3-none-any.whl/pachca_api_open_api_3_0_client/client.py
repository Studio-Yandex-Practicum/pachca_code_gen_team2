import datetime
import logging
import ssl
from http import HTTPStatus
from typing import Any, Optional, Union, cast

import httpx
from attrs import define, evolve, field

from .client_serv import AuthenticatedClient
from .logger_setup import setup_logging
from .models import (CodeReaction, CreateChatBody, CreateChatResponse201,
                     CreateMessageBody, CreateMessageResponse201,
                     CreateTaskBody, CreateTaskResponse201,
                     CreateThreadResponse201, DirectResponse, EditMessageBody,
                     EditMessageResponse200, Errors, FileResponse,
                     GetChatResponse200, GetChatsAvailability,
                     GetChatsResponse200, GetChatsSortid,
                     GetCommonMethodsResponse200, GetEmployeeResponse200,
                     GetEmployeesResponse200, GetListMessageResponse200,
                     GetMessageReactionsResponse200, GetMessageResponse200,
                     GetStatusResponse200, GetTagResponse200,
                     GetTagsEmployeesResponse200, GetTagsResponse200, GroupTag,
                     MembersChat, PutStatusBody, PutStatusResponse200)
from .types import UNSET, Response, Unset


class Pachca:
    """Главный класс библиотеки."""

    def __init__(self, token):
        self.client = AuthenticatedClient(token=token)
        self.logger = setup_logging(__name__)

    async def _get_kwargs_createThread(self, id: int) -> dict[str, Any]:
        _kwargs: dict[str, Any] = {
            "method": "post",
            "url": f"/messages/{id}/thread",
        }
        self.logger.debug("Создание параметров createThread.")
        return _kwargs

    async def _parse_response_createThread(
        self, response: httpx.Response
    ) -> Optional[Union[CreateThreadResponse201, Errors]]:
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для createThread"
        )
        if response.status_code == 201:
            response_201 = CreateThreadResponse201.from_dict(response.json())
            return response_201
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для createThread"
        )
        if response.status_code == 400:
            response_400 = Errors.from_dict(response.json())
            return response_400
        else:
            response_error = Errors.from_dict(response.json())
            return response_error

    async def _build_response_createThread(
        self, response: httpx.Response
    ) -> Response[Union[CreateThreadResponse201, Errors]]:
        self.logger.debug("Преобразование JSON в Python для createThread.")
        return Response(
            status_code=HTTPStatus(response.status_code),
            content=response.content,
            headers=response.headers,
            parsed=await self._parse_response_createThread(response=response),
        )

    async def createThread(
        self, id: int
    ) -> Optional[Union[CreateThreadResponse201, Errors]]:
        """создание нового треда

         Метод для создания нового треда к сообщению. Если у сообщения уже был создан тред, то в ответе
        вернётся информация об уже созданном ранее треде.

        Args:
            id (int):

        Raises:
            errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
            httpx.TimeoutException: If the request takes longer than Client.timeout.

        Returns:
            Union[CreateThreadResponse201, Errors]
        """
        self.logger.info("Начинаем создание ответа на запрос.")
        kwargs = await self._get_kwargs_createThread(id=id)
        response = await (await self.client.get_async_httpx_client()).request(
            **kwargs
        )
        return (
            await self._build_response_createThread(response=response)
        ).parsed

    async def _get_kwargs_getCommonMethods(
        self, entity_type: str
    ) -> dict[str, Any]:
        params: dict[str, Any] = {}
        params["entity_type"] = entity_type
        params = {
            k: v for k, v in params.items() if v is not UNSET and v is not None
        }
        _kwargs: dict[str, Any] = {
            "method": "get",
            "url": "/custom_properties",
            "params": params,
        }
        self.logger.debug("Создание параметров getCommonMethods.")
        return _kwargs

    async def _parse_response_getCommonMethods(
        self, response: httpx.Response
    ) -> Optional[Union[Errors, GetCommonMethodsResponse200]]:
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для getCommonMethods"
        )
        if response.status_code == 200:
            response_200 = GetCommonMethodsResponse200.from_dict(
                response.json()
            )
            return response_200
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для getCommonMethods"
        )
        if response.status_code == 400:
            response_400 = Errors.from_dict(response.json())
            return response_400
        else:
            response_error = Errors.from_dict(response.json())
            return response_error

    async def _build_response_getCommonMethods(
        self, response: httpx.Response
    ) -> Response[Union[Errors, GetCommonMethodsResponse200]]:
        self.logger.debug("Преобразование JSON в Python для getCommonMethods.")
        return Response(
            status_code=HTTPStatus(response.status_code),
            content=response.content,
            headers=response.headers,
            parsed=await self._parse_response_getCommonMethods(
                response=response
            ),
        )

    async def getCommonMethods(
        self, entity_type: str
    ) -> Optional[Union[Errors, GetCommonMethodsResponse200]]:
        """получение списка актульных полей сущности

         Метод для получения актуального списка дополнительных полей участников и напоминаний в вашей
        компании. Тело запроса отсутствует, параметры передаются в URL (например,
        /custom_properties?entity_type=User)

        Args:
            entity_type (str):

        Raises:
            errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
            httpx.TimeoutException: If the request takes longer than Client.timeout.

        Returns:
            Union[Errors, GetCommonMethodsResponse200]
        """
        self.logger.info("Начинаем создание ответа на запрос.")
        kwargs = await self._get_kwargs_getCommonMethods(
            entity_type=entity_type
        )
        response = await (await self.client.get_async_httpx_client()).request(
            **kwargs
        )
        return (
            await self._build_response_getCommonMethods(response=response)
        ).parsed

    async def _get_kwargs_getDirectUrl(
        self, body: DirectResponse
    ) -> dict[str, Any]:
        headers: dict[str, Any] = {}
        _kwargs: dict[str, Any] = {"method": "post", "url": "/direct_url"}
        _body = body.to_multipart()
        _kwargs["files"] = _body
        _kwargs["headers"] = headers
        self.logger.debug("Создание параметров getDirectUrl.")
        return _kwargs

    async def _parse_response_getDirectUrl(
        self, response: httpx.Response
    ) -> Optional[Any]:
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для getDirectUrl"
        )
        if response.status_code == 201:
            return None
        else:
            response_error = Errors.from_dict(response.json())
            return response_error

    async def _build_response_getDirectUrl(
        self, response: httpx.Response
    ) -> Response[Any]:
        self.logger.debug("Преобразование JSON в Python для getDirectUrl.")
        return Response(
            status_code=HTTPStatus(response.status_code),
            content=response.content,
            headers=response.headers,
            parsed=await self._parse_response_getDirectUrl(response=response),
        )

    async def getDirectUrl(self, body: DirectResponse) -> Optional[Any]:
        """(полученный в ответе на запрос /uploads) загрузка файла

         Данный метод не требует авторизации.

        Получив все параметры, вам необходимо сделать POST запрос в формате multipart/form-data на адрес,
        который был указан в поле direct_url, отправив полученные параметры и сам файл.

        Args:
            body (DirectResponse):

        Raises:
            errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
            httpx.TimeoutException: If the request takes longer than Client.timeout.

        Returns:
            Any
        """
        self.logger.info("Начинаем создание ответа на запрос.")
        kwargs = await self._get_kwargs_getDirectUrl(body=body)
        response = await (await self.client.get_async_httpx_client()).request(
            **kwargs
        )
        return (
            await self._build_response_getDirectUrl(response=response)
        ).parsed

    async def _get_kwargs_getUploads(self) -> dict[str, Any]:
        _kwargs: dict[str, Any] = {"method": "post", "url": "/uploads"}
        self.logger.debug("Создание параметров getUploads.")
        return _kwargs

    async def _parse_response_getUploads(
        self, response: httpx.Response
    ) -> Optional[FileResponse]:
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для getUploads"
        )
        if response.status_code == 200:
            response_200 = FileResponse.from_dict(response.json())
            return response_200
        else:
            response_error = Errors.from_dict(response.json())
            return response_error

    async def _build_response_getUploads(
        self, response: httpx.Response
    ) -> Response[FileResponse]:
        self.logger.debug("Преобразование JSON в Python для getUploads.")
        return Response(
            status_code=HTTPStatus(response.status_code),
            content=response.content,
            headers=response.headers,
            parsed=await self._parse_response_getUploads(response=response),
        )

    async def getUploads(self) -> Optional[FileResponse]:
        """получения подписи и ключа для загрузки файла

         Данный метод необходимо использовать для загрузки каждого файла.

        Данный метод позволяет получить уникальный набор параметров для загрузки файла. Параметры запроса
        отсутствуют.

        Raises:
            errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
            httpx.TimeoutException: If the request takes longer than Client.timeout.

        Returns:
            FileResponse
        """
        self.logger.info("Начинаем создание ответа на запрос.")
        kwargs = await self._get_kwargs_getUploads()
        response = await (await self.client.get_async_httpx_client()).request(
            **kwargs
        )
        return (
            await self._build_response_getUploads(response=response)
        ).parsed

    async def _get_kwargs_editMessage(
        self, id: int, body: EditMessageBody
    ) -> dict[str, Any]:
        headers: dict[str, Any] = {}
        _kwargs: dict[str, Any] = {"method": "put", "url": f"/messages/{id}"}
        _body = body.to_dict()
        _kwargs["json"] = _body
        headers["Content-Type"] = "application/json"
        _kwargs["headers"] = headers
        self.logger.debug("Создание параметров editMessage.")
        return _kwargs

    async def _parse_response_editMessage(
        self, response: httpx.Response
    ) -> Optional[Union[EditMessageResponse200, Errors]]:
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для editMessage"
        )
        if response.status_code == 200:
            response_200 = EditMessageResponse200.from_dict(response.json())
            return response_200
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для editMessage"
        )
        if response.status_code == 400:
            response_400 = Errors.from_dict(response.json())
            return response_400
        else:
            response_error = Errors.from_dict(response.json())
            return response_error

    async def _build_response_editMessage(
        self, response: httpx.Response
    ) -> Response[Union[EditMessageResponse200, Errors]]:
        self.logger.debug("Преобразование JSON в Python для editMessage.")
        return Response(
            status_code=HTTPStatus(response.status_code),
            content=response.content,
            headers=response.headers,
            parsed=await self._parse_response_editMessage(response=response),
        )

    async def editMessage(
        self, id: int, body: EditMessageBody
    ) -> Optional[Union[EditMessageResponse200, Errors]]:
        """редактирование сообщения по указанному идентификатору

         Метод для редактирования сообщения или комментария.

        Args:
            id (int):
            body (EditMessageBody):

        Raises:
            errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
            httpx.TimeoutException: If the request takes longer than Client.timeout.

        Returns:
            Union[EditMessageResponse200, Errors]
        """
        self.logger.info("Начинаем создание ответа на запрос.")
        kwargs = await self._get_kwargs_editMessage(id=id, body=body)
        response = await (await self.client.get_async_httpx_client()).request(
            **kwargs
        )
        return (
            await self._build_response_editMessage(response=response)
        ).parsed

    async def _get_kwargs_createMessage(
        self, body: CreateMessageBody
    ) -> dict[str, Any]:
        headers: dict[str, Any] = {}
        _kwargs: dict[str, Any] = {"method": "post", "url": "/messages"}
        _body = body.to_dict()
        _kwargs["json"] = _body
        headers["Content-Type"] = "application/json"
        _kwargs["headers"] = headers
        self.logger.debug("Создание параметров createMessage.")
        return _kwargs

    async def _parse_response_createMessage(
        self, response: httpx.Response
    ) -> Optional[Union[CreateMessageResponse201, Errors]]:
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для createMessage"
        )
        if response.status_code == 201:
            response_201 = CreateMessageResponse201.from_dict(response.json())
            return response_201
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для createMessage"
        )
        if response.status_code == 400:
            response_400 = Errors.from_dict(response.json())
            return response_400
        else:
            response_error = Errors.from_dict(response.json())
            return response_error

    async def _build_response_createMessage(
        self, response: httpx.Response
    ) -> Response[Union[CreateMessageResponse201, Errors]]:
        self.logger.debug("Преобразование JSON в Python для createMessage.")
        return Response(
            status_code=HTTPStatus(response.status_code),
            content=response.content,
            headers=response.headers,
            parsed=await self._parse_response_createMessage(response=response),
        )

    async def createMessage(
        self, body: CreateMessageBody
    ) -> Optional[Union[CreateMessageResponse201, Errors]]:
        """создание нового сообщения

         Метод для отправки сообщения в беседу или канал,
        личного сообщения пользователю или комментария в тред.

        При использовании entity_type: \\"discussion\\" (или просто без указания entity_type)
        допускается отправка любого chat_id в поле entity_id.
        То есть, сообщение можно отправить зная только идентификатор чата.
        При этом, вы имеете возможность отправить сообщение в тред по его идентификатору
        или личное сообщение по идентификатору пользователя.

        Для отправки личного сообщения пользователю создавать чат не требуется.
        Достаточно указать entity_type: \\"user\\" и идентификатор пользователя.
        Чат будет создан автоматически, если между вами ещё не было переписки.
        Между двумя пользователями может быть только один личный чат.

        Args:
            body (CreateMessageBody):

        Raises:
            errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
            httpx.TimeoutException: If the request takes longer than Client.timeout.

        Returns:
            Union[CreateMessageResponse201, Errors]
        """
        self.logger.info("Начинаем создание ответа на запрос.")
        kwargs = await self._get_kwargs_createMessage(body=body)
        response = await (await self.client.get_async_httpx_client()).request(
            **kwargs
        )
        return (
            await self._build_response_createMessage(response=response)
        ).parsed

    async def _get_kwargs_getMessage(self, id: int) -> dict[str, Any]:
        _kwargs: dict[str, Any] = {"method": "get", "url": f"/messages/{id}"}
        self.logger.debug("Создание параметров getMessage.")
        return _kwargs

    async def _parse_response_getMessage(
        self, response: httpx.Response
    ) -> Optional[Union[Errors, GetMessageResponse200]]:
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для getMessage"
        )
        if response.status_code == 200:
            response_200 = GetMessageResponse200.from_dict(response.json())
            return response_200
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для getMessage"
        )
        if response.status_code == 400:
            response_400 = Errors.from_dict(response.json())
            return response_400
        else:
            response_error = Errors.from_dict(response.json())
            return response_error

    async def _build_response_getMessage(
        self, response: httpx.Response
    ) -> Response[Union[Errors, GetMessageResponse200]]:
        self.logger.debug("Преобразование JSON в Python для getMessage.")
        return Response(
            status_code=HTTPStatus(response.status_code),
            content=response.content,
            headers=response.headers,
            parsed=await self._parse_response_getMessage(response=response),
        )

    async def getMessage(
        self, id: int
    ) -> Optional[Union[Errors, GetMessageResponse200]]:
        """получение информации о сообщении

         Метод для получения информации о сообщении.

        Для получения сообщения вам необходимо знать его id и указать его в URL запроса.

        Args:
            id (int):

        Raises:
            errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
            httpx.TimeoutException: If the request takes longer than Client.timeout.

        Returns:
            Union[Errors, GetMessageResponse200]
        """
        self.logger.info("Начинаем создание ответа на запрос.")
        kwargs = await self._get_kwargs_getMessage(id=id)
        response = await (await self.client.get_async_httpx_client()).request(
            **kwargs
        )
        return (
            await self._build_response_getMessage(response=response)
        ).parsed

    async def _get_kwargs_getListMessage(
        self,
        chat_id: int,
        per: Union[Unset, int] = 25,
        page: Union[Unset, int] = 1,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {}
        params["chat_id"] = chat_id
        params["per"] = per
        params["page"] = page
        params = {
            k: v for k, v in params.items() if v is not UNSET and v is not None
        }
        _kwargs: dict[str, Any] = {
            "method": "get",
            "url": "/messages",
            "params": params,
        }
        self.logger.debug("Создание параметров getListMessage.")
        return _kwargs

    async def _parse_response_getListMessage(
        self, response: httpx.Response
    ) -> Optional[Union[Errors, GetListMessageResponse200]]:
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для getListMessage"
        )
        if response.status_code == 200:
            response_200 = GetListMessageResponse200.from_dict(response.json())
            return response_200
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для getListMessage"
        )
        if response.status_code == 400:
            response_400 = Errors.from_dict(response.json())
            return response_400
        else:
            response_error = Errors.from_dict(response.json())
            return response_error

    async def _build_response_getListMessage(
        self, response: httpx.Response
    ) -> Response[Union[Errors, GetListMessageResponse200]]:
        self.logger.debug("Преобразование JSON в Python для getListMessage.")
        return Response(
            status_code=HTTPStatus(response.status_code),
            content=response.content,
            headers=response.headers,
            parsed=await self._parse_response_getListMessage(
                response=response
            ),
        )

    async def getListMessage(
        self,
        chat_id: int,
        per: Union[Unset, int] = 25,
        page: Union[Unset, int] = 1,
    ) -> Optional[Union[Errors, GetListMessageResponse200]]:
        """получение списка сообщений чата

         Метод для получения списка сообщений бесед, каналов, тредов и личных сообщений.

        Для получения сообщений вам необходимо знать chat_id требуемой беседы, канала,
        треда или диалога, и указать его в URL запроса. Сообщения будут возвращены
        в порядке убывания даты отправки (то есть, сначала будут идти последние сообщения чата).
        Для получения более ранних сообщений чата доступны параметры per и page.
        Тело запроса отсутствует, параметры передаются в URL (например, /messages?chat_id=198&per=3)

        Args:
            chat_id (int):
            per (Union[Unset, int]):  Default: 25.
            page (Union[Unset, int]):  Default: 1.

        Raises:
            errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
            httpx.TimeoutException: If the request takes longer than Client.timeout.

        Returns:
            Union[Errors, GetListMessageResponse200]
        """
        self.logger.info("Начинаем создание ответа на запрос.")
        kwargs = await self._get_kwargs_getListMessage(
            chat_id=chat_id, per=per, page=page
        )
        response = await (await self.client.get_async_httpx_client()).request(
            **kwargs
        )
        return (
            await self._build_response_getListMessage(response=response)
        ).parsed

    async def _get_kwargs_postTagsToChats(
        self, id: int, body: GroupTag
    ) -> dict[str, Any]:
        headers: dict[str, Any] = {}
        _kwargs: dict[str, Any] = {
            "method": "post",
            "url": f"/chats/{id}/group_tags",
        }
        _body = body.to_dict()
        _kwargs["json"] = _body
        headers["Content-Type"] = "application/json"
        _kwargs["headers"] = headers
        self.logger.debug("Создание параметров postTagsToChats.")
        return _kwargs

    async def _parse_response_postTagsToChats(
        self, response: httpx.Response
    ) -> Optional[Union[Any, Errors]]:
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для postTagsToChats"
        )
        if response.status_code == 204:
            response_204 = cast(Any, None)
            return response_204
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для postTagsToChats"
        )
        if response.status_code == 400:
            response_400 = Errors.from_dict(response.json())
            return response_400
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для postTagsToChats"
        )
        if response.status_code == 422:
            response_422 = Errors.from_dict(response.json())
            return response_422
        else:
            response_error = Errors.from_dict(response.json())
            return response_error

    async def _build_response_postTagsToChats(
        self, response: httpx.Response
    ) -> Response[Union[Any, Errors]]:
        self.logger.debug("Преобразование JSON в Python для postTagsToChats.")
        return Response(
            status_code=HTTPStatus(response.status_code),
            content=response.content,
            headers=response.headers,
            parsed=await self._parse_response_postTagsToChats(
                response=response
            ),
        )

    async def postTagsToChats(
        self, id: int, body: GroupTag
    ) -> Optional[Union[Any, Errors]]:
        """добавление тегов в состав участников беседы или канала

         Метод для добавления тегов в состав участников беседы или канала.

        Args:
            id (int):  Example: 533.
            body (GroupTag):

        Raises:
            errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
            httpx.TimeoutException: If the request takes longer than Client.timeout.

        Returns:
            Union[Any, Errors]
        """
        self.logger.info("Начинаем создание ответа на запрос.")
        kwargs = await self._get_kwargs_postTagsToChats(id=id, body=body)
        response = await (await self.client.get_async_httpx_client()).request(
            **kwargs
        )
        return (
            await self._build_response_postTagsToChats(response=response)
        ).parsed

    async def _get_kwargs_postMembersToChats(
        self, id: int, body: MembersChat
    ) -> dict[str, Any]:
        headers: dict[str, Any] = {}
        _kwargs: dict[str, Any] = {
            "method": "post",
            "url": f"/chats/{id}/members",
        }
        _body = body.to_dict()
        _kwargs["json"] = _body
        headers["Content-Type"] = "application/json"
        _kwargs["headers"] = headers
        self.logger.debug("Создание параметров postMembersToChats.")
        return _kwargs

    async def _parse_response_postMembersToChats(
        self, response: httpx.Response
    ) -> Optional[Union[Any, Errors]]:
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для postMembersToChats"
        )
        if response.status_code == 204:
            response_204 = cast(Any, None)
            return response_204
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для postMembersToChats"
        )
        if response.status_code == 400:
            response_400 = Errors.from_dict(response.json())
            return response_400
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для postMembersToChats"
        )
        if response.status_code == 422:
            response_422 = Errors.from_dict(response.json())
            return response_422
        else:
            response_error = Errors.from_dict(response.json())
            return response_error

    async def _build_response_postMembersToChats(
        self, response: httpx.Response
    ) -> Response[Union[Any, Errors]]:
        self.logger.debug(
            "Преобразование JSON в Python для postMembersToChats."
        )
        return Response(
            status_code=HTTPStatus(response.status_code),
            content=response.content,
            headers=response.headers,
            parsed=await self._parse_response_postMembersToChats(
                response=response
            ),
        )

    async def postMembersToChats(
        self, id: int, body: MembersChat
    ) -> Optional[Union[Any, Errors]]:
        """добавление пользователей в состав участников

         Метод для добавления пользователей в состав участников беседы или канала.

        Args:
            id (int):  Example: 533.
            body (MembersChat):

        Raises:
            errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
            httpx.TimeoutException: If the request takes longer than Client.timeout.

        Returns:
            Union[Any, Errors]
        """
        self.logger.info("Начинаем создание ответа на запрос.")
        kwargs = await self._get_kwargs_postMembersToChats(id=id, body=body)
        response = await (await self.client.get_async_httpx_client()).request(
            **kwargs
        )
        return (
            await self._build_response_postMembersToChats(response=response)
        ).parsed

    async def _get_kwargs_leaveChat(self, id: int) -> dict[str, Any]:
        _kwargs: dict[str, Any] = {
            "method": "delete",
            "url": f"/chats/{id}/leave",
        }
        self.logger.debug("Создание параметров leaveChat.")
        return _kwargs

    async def _parse_response_leaveChat(
        self, response: httpx.Response
    ) -> Optional[Union[Any, Errors]]:
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для leaveChat"
        )
        if response.status_code == 204:
            response_204 = cast(Any, None)
            return response_204
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для leaveChat"
        )
        if response.status_code == 400:
            response_400 = Errors.from_dict(response.json())
            return response_400
        else:
            response_error = Errors.from_dict(response.json())
            return response_error

    async def _build_response_leaveChat(
        self, response: httpx.Response
    ) -> Response[Union[Any, Errors]]:
        self.logger.debug("Преобразование JSON в Python для leaveChat.")
        return Response(
            status_code=HTTPStatus(response.status_code),
            content=response.content,
            headers=response.headers,
            parsed=await self._parse_response_leaveChat(response=response),
        )

    async def leaveChat(self, id: int) -> Optional[Union[Any, Errors]]:
        """выход из беседы или канала

         Метод для самостоятельного выхода из беседы или канала. Параметры запроса отсутствуют/

        Args:
            id (int):

        Raises:
            errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
            httpx.TimeoutException: If the request takes longer than Client.timeout.

        Returns:
            Union[Any, Errors]
        """
        self.logger.info("Начинаем создание ответа на запрос.")
        kwargs = await self._get_kwargs_leaveChat(id=id)
        response = await (await self.client.get_async_httpx_client()).request(
            **kwargs
        )
        return (await self._build_response_leaveChat(response=response)).parsed

    async def _get_kwargs_getChat(self, id: int) -> dict[str, Any]:
        _kwargs: dict[str, Any] = {"method": "get", "url": f"/chats/{id}"}
        self.logger.debug("Создание параметров getChat.")
        return _kwargs

    async def _parse_response_getChat(
        self, response: httpx.Response
    ) -> Optional[Union[Errors, GetChatResponse200]]:
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для getChat"
        )
        if response.status_code == 200:
            response_200 = GetChatResponse200.from_dict(response.json())
            return response_200
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для getChat"
        )
        if response.status_code == 400:
            response_400 = Errors.from_dict(response.json())
            return response_400
        else:
            response_error = Errors.from_dict(response.json())
            return response_error

    async def _build_response_getChat(
        self, response: httpx.Response
    ) -> Response[Union[Errors, GetChatResponse200]]:
        self.logger.debug("Преобразование JSON в Python для getChat.")
        return Response(
            status_code=HTTPStatus(response.status_code),
            content=response.content,
            headers=response.headers,
            parsed=await self._parse_response_getChat(response=response),
        )

    async def getChat(
        self, id: int
    ) -> Optional[Union[Errors, GetChatResponse200]]:
        """получение информации о беседе или канале

         Получения информации о беседе или канале.
        Для получения беседы или канала вам необходимо знать её id и указать его в URL запроса.

        Args:
            id (int):

        Raises:
            errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
            httpx.TimeoutException: If the request takes longer than Client.timeout.

        Returns:
            Union[Errors, GetChatResponse200]
        """
        self.logger.info("Начинаем создание ответа на запрос.")
        kwargs = await self._get_kwargs_getChat(id=id)
        response = await (await self.client.get_async_httpx_client()).request(
            **kwargs
        )
        return (await self._build_response_getChat(response=response)).parsed

    async def _get_kwargs_createChat(
        self, body: CreateChatBody
    ) -> dict[str, Any]:
        headers: dict[str, Any] = {}
        _kwargs: dict[str, Any] = {"method": "post", "url": "/chats"}
        _body = body.to_dict()
        _kwargs["json"] = _body
        headers["Content-Type"] = "application/json"
        _kwargs["headers"] = headers
        self.logger.debug("Создание параметров createChat.")
        return _kwargs

    async def _parse_response_createChat(
        self, response: httpx.Response
    ) -> Optional[Union[CreateChatResponse201, Errors]]:
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для createChat"
        )
        if response.status_code == 201:
            response_201 = CreateChatResponse201.from_dict(response.json())
            return response_201
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для createChat"
        )
        if response.status_code == 400:
            response_400 = Errors.from_dict(response.json())
            return response_400
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для createChat"
        )
        if response.status_code == 422:
            response_422 = Errors.from_dict(response.json())
            return response_422
        else:
            response_error = Errors.from_dict(response.json())
            return response_error

    async def _build_response_createChat(
        self, response: httpx.Response
    ) -> Response[Union[CreateChatResponse201, Errors]]:
        self.logger.debug("Преобразование JSON в Python для createChat.")
        return Response(
            status_code=HTTPStatus(response.status_code),
            content=response.content,
            headers=response.headers,
            parsed=await self._parse_response_createChat(response=response),
        )

    async def createChat(
        self, body: CreateChatBody
    ) -> Optional[Union[CreateChatResponse201, Errors]]:
        """создание новой беседы или канала

         Метод для создания новой беседы или нового канала.
        При создании беседы или канала вы автоматически становитесь участником.

        Args:
            body (CreateChatBody):

        Raises:
            errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
            httpx.TimeoutException: If the request takes longer than Client.timeout.

        Returns:
            Union[CreateChatResponse201, Errors]
        """
        self.logger.info("Начинаем создание ответа на запрос.")
        kwargs = await self._get_kwargs_createChat(body=body)
        response = await (await self.client.get_async_httpx_client()).request(
            **kwargs
        )
        return (
            await self._build_response_createChat(response=response)
        ).parsed

    async def _get_kwargs_getChats(
        self,
        sortid: Union[Unset, GetChatsSortid] = GetChatsSortid.DESC,
        per: Union[Unset, int] = 25,
        page: Union[Unset, int] = 1,
        availability: Union[
            Unset, GetChatsAvailability
        ] = GetChatsAvailability.IS_MEMBER,
        last_message_at_after: Union[Unset, datetime.datetime] = UNSET,
        last_message_at_before: Union[Unset, datetime.datetime] = UNSET,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {}
        json_sortid: Union[Unset, str] = UNSET
        if not isinstance(sortid, Unset):
            json_sortid = sortid.value
        params["sort[id]"] = json_sortid
        params["per"] = per
        params["page"] = page
        json_availability: Union[Unset, str] = UNSET
        if not isinstance(availability, Unset):
            json_availability = availability.value
        params["availability"] = json_availability
        json_last_message_at_after: Union[Unset, str] = UNSET
        if not isinstance(last_message_at_after, Unset):
            json_last_message_at_after = last_message_at_after.isoformat()
        params["last_message_at_after"] = json_last_message_at_after
        json_last_message_at_before: Union[Unset, str] = UNSET
        if not isinstance(last_message_at_before, Unset):
            json_last_message_at_before = last_message_at_before.isoformat()
        params["last_message_at_before"] = json_last_message_at_before
        params = {
            k: v for k, v in params.items() if v is not UNSET and v is not None
        }
        _kwargs: dict[str, Any] = {
            "method": "get",
            "url": "/chats",
            "params": params,
        }
        self.logger.debug("Создание параметров getChats.")
        return _kwargs

    async def _parse_response_getChats(
        self, response: httpx.Response
    ) -> Optional[Union[Errors, GetChatsResponse200]]:
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для getChats"
        )
        if response.status_code == 200:
            response_200 = GetChatsResponse200.from_dict(response.json())
            return response_200
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для getChats"
        )
        if response.status_code == 400:
            response_400 = Errors.from_dict(response.json())
            return response_400
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для getChats"
        )
        if response.status_code == 422:
            response_422 = Errors.from_dict(response.json())
            return response_422
        else:
            response_error = Errors.from_dict(response.json())
            return response_error

    async def _build_response_getChats(
        self, response: httpx.Response
    ) -> Response[Union[Errors, GetChatsResponse200]]:
        self.logger.debug("Преобразование JSON в Python для getChats.")
        return Response(
            status_code=HTTPStatus(response.status_code),
            content=response.content,
            headers=response.headers,
            parsed=await self._parse_response_getChats(response=response),
        )

    async def getChats(
        self,
        sortid: Union[Unset, GetChatsSortid] = GetChatsSortid.DESC,
        per: Union[Unset, int] = 25,
        page: Union[Unset, int] = 1,
        availability: Union[
            Unset, GetChatsAvailability
        ] = GetChatsAvailability.IS_MEMBER,
        last_message_at_after: Union[Unset, datetime.datetime] = UNSET,
        last_message_at_before: Union[Unset, datetime.datetime] = UNSET,
    ) -> Optional[Union[Errors, GetChatsResponse200]]:
        """получение списка бесед и каналов

         Метод для получения списка бесед и каналов по заданным параметрам.

        Тело запроса отсутствует, параметры передаются в URL (например, /chats?per=2&sort[id]=desc)

        Args:
            sortid (Union[Unset, GetChatsSortid]):  Default: GetChatsSortid.DESC.
            per (Union[Unset, int]):  Default: 25.
            page (Union[Unset, int]):  Default: 1.
            availability (Union[Unset, GetChatsAvailability]):  Default:
                GetChatsAvailability.IS_MEMBER.
            last_message_at_after (Union[Unset, datetime.datetime]):
            last_message_at_before (Union[Unset, datetime.datetime]):

        Raises:
            errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
            httpx.TimeoutException: If the request takes longer than Client.timeout.

        Returns:
            Union[Errors, GetChatsResponse200]
        """
        self.logger.info("Начинаем создание ответа на запрос.")
        kwargs = await self._get_kwargs_getChats(
            sortid=sortid,
            per=per,
            page=page,
            availability=availability,
            last_message_at_after=last_message_at_after,
            last_message_at_before=last_message_at_before,
        )
        response = await (await self.client.get_async_httpx_client()).request(
            **kwargs
        )
        return (await self._build_response_getChats(response=response)).parsed

    async def _get_kwargs_getStatus(self) -> dict[str, Any]:
        _kwargs: dict[str, Any] = {"method": "get", "url": "/profile/status"}
        self.logger.debug("Создание параметров getStatus.")
        return _kwargs

    async def _parse_response_getStatus(
        self, response: httpx.Response
    ) -> Optional[GetStatusResponse200]:
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для getStatus"
        )
        if response.status_code == 200:
            response_200 = GetStatusResponse200.from_dict(response.json())
            return response_200
        else:
            response_error = Errors.from_dict(response.json())
            return response_error

    async def _build_response_getStatus(
        self, response: httpx.Response
    ) -> Response[GetStatusResponse200]:
        self.logger.debug("Преобразование JSON в Python для getStatus.")
        return Response(
            status_code=HTTPStatus(response.status_code),
            content=response.content,
            headers=response.headers,
            parsed=await self._parse_response_getStatus(response=response),
        )

    async def getStatus(self) -> Optional[GetStatusResponse200]:
        """получение информации о своем статусе

         Метод для получения информации о своем статусе. Параметры запроса отсутствуют.

        Raises:
            errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
            httpx.TimeoutException: If the request takes longer than Client.timeout.

        Returns:
            GetStatusResponse200
        """
        self.logger.info("Начинаем создание ответа на запрос.")
        kwargs = await self._get_kwargs_getStatus()
        response = await (await self.client.get_async_httpx_client()).request(
            **kwargs
        )
        return (await self._build_response_getStatus(response=response)).parsed

    async def _get_kwargs_putStatus(
        self, body: PutStatusBody
    ) -> dict[str, Any]:
        headers: dict[str, Any] = {}
        _kwargs: dict[str, Any] = {"method": "put", "url": "/profile/status"}
        _body = body.to_dict()
        _kwargs["json"] = _body
        headers["Content-Type"] = "application/json"
        _kwargs["headers"] = headers
        self.logger.debug("Создание параметров putStatus.")
        return _kwargs

    async def _parse_response_putStatus(
        self, response: httpx.Response
    ) -> Optional[Union[Errors, PutStatusResponse200]]:
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для putStatus"
        )
        if response.status_code == 200:
            response_200 = PutStatusResponse200.from_dict(response.json())
            return response_200
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для putStatus"
        )
        if response.status_code == 400:
            response_400 = Errors.from_dict(response.json())
            return response_400
        else:
            response_error = Errors.from_dict(response.json())
            return response_error

    async def _build_response_putStatus(
        self, response: httpx.Response
    ) -> Response[Union[Errors, PutStatusResponse200]]:
        self.logger.debug("Преобразование JSON в Python для putStatus.")
        return Response(
            status_code=HTTPStatus(response.status_code),
            content=response.content,
            headers=response.headers,
            parsed=await self._parse_response_putStatus(response=response),
        )

    async def putStatus(
        self, body: PutStatusBody
    ) -> Optional[Union[Errors, PutStatusResponse200]]:
        """новый статус

         Метод для установки себе нового статуса.

        Args:
            body (PutStatusBody):

        Raises:
            errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
            httpx.TimeoutException: If the request takes longer than Client.timeout.

        Returns:
            Union[Errors, PutStatusResponse200]
        """
        self.logger.info("Начинаем создание ответа на запрос.")
        kwargs = await self._get_kwargs_putStatus(body=body)
        response = await (await self.client.get_async_httpx_client()).request(
            **kwargs
        )
        return (await self._build_response_putStatus(response=response)).parsed

    async def _get_kwargs_delStatus(self) -> dict[str, Any]:
        _kwargs: dict[str, Any] = {
            "method": "delete",
            "url": "/profile/status",
        }
        self.logger.debug("Создание параметров delStatus.")
        return _kwargs

    async def _parse_response_delStatus(
        self, response: httpx.Response
    ) -> Optional[Any]:
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для delStatus"
        )
        if response.status_code == 204:
            return None
        else:
            response_error = Errors.from_dict(response.json())
            return response_error

    async def _build_response_delStatus(
        self, response: httpx.Response
    ) -> Response[Any]:
        self.logger.debug("Преобразование JSON в Python для delStatus.")
        return Response(
            status_code=HTTPStatus(response.status_code),
            content=response.content,
            headers=response.headers,
            parsed=await self._parse_response_delStatus(response=response),
        )

    async def delStatus(self) -> Optional[Any]:
        """удаление своего статуса

         Метод для удаления своего статуса. Параметры запроса отсутствуют.

        Raises:
            errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
            httpx.TimeoutException: If the request takes longer than Client.timeout.

        Returns:
            Any
        """
        self.logger.info("Начинаем создание ответа на запрос.")
        kwargs = await self._get_kwargs_delStatus()
        response = await (await self.client.get_async_httpx_client()).request(
            **kwargs
        )
        return (await self._build_response_delStatus(response=response)).parsed

    async def _get_kwargs_getTags(
        self, per: Union[Unset, int] = 50, page: Union[Unset, int] = 1
    ) -> dict[str, Any]:
        params: dict[str, Any] = {}
        params["per"] = per
        params["page"] = page
        params = {
            k: v for k, v in params.items() if v is not UNSET and v is not None
        }
        _kwargs: dict[str, Any] = {
            "method": "get",
            "url": "/group_tags",
            "params": params,
        }
        self.logger.debug("Создание параметров getTags.")
        return _kwargs

    async def _parse_response_getTags(
        self, response: httpx.Response
    ) -> Optional[Union[Errors, GetTagsResponse200]]:
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для getTags"
        )
        if response.status_code == 200:
            response_200 = GetTagsResponse200.from_dict(response.json())
            return response_200
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для getTags"
        )
        if response.status_code == 400:
            response_400 = Errors.from_dict(response.json())
            return response_400
        else:
            response_error = Errors.from_dict(response.json())
            return response_error

    async def _build_response_getTags(
        self, response: httpx.Response
    ) -> Response[Union[Errors, GetTagsResponse200]]:
        self.logger.debug("Преобразование JSON в Python для getTags.")
        return Response(
            status_code=HTTPStatus(response.status_code),
            content=response.content,
            headers=response.headers,
            parsed=await self._parse_response_getTags(response=response),
        )

    async def getTags(
        self, per: Union[Unset, int] = 50, page: Union[Unset, int] = 1
    ) -> Optional[Union[Errors, GetTagsResponse200]]:
        """получение актуального списка тегов сотрудников

         Метод для получения актуального списка тегов сотрудников.

        Названия тегов являются уникальными в компании. Тело запроса отсутствует, параметры передаются в URL
        (например, /group_tags?per=10&page=2)

        Args:
            per (Union[Unset, int]):  Default: 50.
            page (Union[Unset, int]):  Default: 1.

        Raises:
            errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
            httpx.TimeoutException: If the request takes longer than Client.timeout.

        Returns:
            Union[Errors, GetTagsResponse200]
        """
        self.logger.info("Начинаем создание ответа на запрос.")
        kwargs = await self._get_kwargs_getTags(per=per, page=page)
        response = await (await self.client.get_async_httpx_client()).request(
            **kwargs
        )
        return (await self._build_response_getTags(response=response)).parsed

    async def _get_kwargs_getTag(self, id: int) -> dict[str, Any]:
        _kwargs: dict[str, Any] = {"method": "get", "url": f"/group_tags/{id}"}
        self.logger.debug("Создание параметров getTag.")
        return _kwargs

    async def _parse_response_getTag(
        self, response: httpx.Response
    ) -> Optional[Union[Errors, GetTagResponse200]]:
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для getTag"
        )
        if response.status_code == 200:
            response_200 = GetTagResponse200.from_dict(response.json())
            return response_200
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для getTag"
        )
        if response.status_code == 400:
            response_400 = Errors.from_dict(response.json())
            return response_400
        else:
            response_error = Errors.from_dict(response.json())
            return response_error

    async def _build_response_getTag(
        self, response: httpx.Response
    ) -> Response[Union[Errors, GetTagResponse200]]:
        self.logger.debug("Преобразование JSON в Python для getTag.")
        return Response(
            status_code=HTTPStatus(response.status_code),
            content=response.content,
            headers=response.headers,
            parsed=await self._parse_response_getTag(response=response),
        )

    async def getTag(
        self, id: int
    ) -> Optional[Union[Errors, GetTagResponse200]]:
        """получение информации о теге

         Метод для получения информации о теге. Названия тегов являются уникальными в компании.

        Для получения тега вам необходимо знать его id и указать его в URL запроса. Параметры запроса
        отсутствуют

        Args:
            id (int):

        Raises:
            errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
            httpx.TimeoutException: If the request takes longer than Client.timeout.

        Returns:
            Union[Errors, GetTagResponse200]
        """
        self.logger.info("Начинаем создание ответа на запрос.")
        kwargs = await self._get_kwargs_getTag(id=id)
        response = await (await self.client.get_async_httpx_client()).request(
            **kwargs
        )
        return (await self._build_response_getTag(response=response)).parsed

    async def _get_kwargs_getTagsEmployees(
        self, id: int, per: Union[Unset, int] = 25, page: Union[Unset, int] = 1
    ) -> dict[str, Any]:
        params: dict[str, Any] = {}
        params["per"] = per
        params["page"] = page
        params = {
            k: v for k, v in params.items() if v is not UNSET and v is not None
        }
        _kwargs: dict[str, Any] = {
            "method": "get",
            "url": f"/group_tags/{id}/users",
            "params": params,
        }
        self.logger.debug("Создание параметров getTagsEmployees.")
        return _kwargs

    async def _parse_response_getTagsEmployees(
        self, response: httpx.Response
    ) -> Optional[Union[Errors, GetTagsEmployeesResponse200]]:
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для getTagsEmployees"
        )
        if response.status_code == 200:
            response_200 = GetTagsEmployeesResponse200.from_dict(
                response.json()
            )
            return response_200
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для getTagsEmployees"
        )
        if response.status_code == 400:
            response_400 = Errors.from_dict(response.json())
            return response_400
        else:
            response_error = Errors.from_dict(response.json())
            return response_error

    async def _build_response_getTagsEmployees(
        self, response: httpx.Response
    ) -> Response[Union[Errors, GetTagsEmployeesResponse200]]:
        self.logger.debug("Преобразование JSON в Python для getTagsEmployees.")
        return Response(
            status_code=HTTPStatus(response.status_code),
            content=response.content,
            headers=response.headers,
            parsed=await self._parse_response_getTagsEmployees(
                response=response
            ),
        )

    async def getTagsEmployees(
        self, id: int, per: Union[Unset, int] = 25, page: Union[Unset, int] = 1
    ) -> Optional[Union[Errors, GetTagsEmployeesResponse200]]:
        """получение актуального списка сотрудников тега

         Метод для получения актуального списка сотрудников тега.

        Идентификатор тега, список сотрудников которого необходимо получить, и другие параметры передаются в
        URL (например, /group_tags/877650/users?per=3&page=2)

        Args:
            id (int):
            per (Union[Unset, int]):  Default: 25.
            page (Union[Unset, int]):  Default: 1.

        Raises:
            errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
            httpx.TimeoutException: If the request takes longer than Client.timeout.

        Returns:
            Union[Errors, GetTagsEmployeesResponse200]
        """
        self.logger.info("Начинаем создание ответа на запрос.")
        kwargs = await self._get_kwargs_getTagsEmployees(
            id=id, per=per, page=page
        )
        response = await (await self.client.get_async_httpx_client()).request(
            **kwargs
        )
        return (
            await self._build_response_getTagsEmployees(response=response)
        ).parsed

    async def _get_kwargs_createTask(
        self, body: CreateTaskBody
    ) -> dict[str, Any]:
        headers: dict[str, Any] = {}
        _kwargs: dict[str, Any] = {"method": "post", "url": "/tasks"}
        _body = body.to_dict()
        _kwargs["json"] = _body
        headers["Content-Type"] = "application/json"
        _kwargs["headers"] = headers
        self.logger.debug("Создание параметров createTask.")
        return _kwargs

    async def _parse_response_createTask(
        self, response: httpx.Response
    ) -> Optional[Union[CreateTaskResponse201, Errors]]:
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для createTask"
        )
        if response.status_code == 201:
            response_201 = CreateTaskResponse201.from_dict(response.json())
            return response_201
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для createTask"
        )
        if response.status_code == 400:
            response_400 = Errors.from_dict(response.json())
            return response_400
        else:
            response_error = Errors.from_dict(response.json())
            return response_error

    async def _build_response_createTask(
        self, response: httpx.Response
    ) -> Response[Union[CreateTaskResponse201, Errors]]:
        self.logger.debug("Преобразование JSON в Python для createTask.")
        return Response(
            status_code=HTTPStatus(response.status_code),
            content=response.content,
            headers=response.headers,
            parsed=await self._parse_response_createTask(response=response),
        )

    async def createTask(
        self, body: CreateTaskBody
    ) -> Optional[Union[CreateTaskResponse201, Errors]]:
        """создание нового напоминания

         Метод для создания нового напоминания.

        При создании напоминания обязательным условием является указания типа напоминания: звонок, встреча,
        простое напоминание, событие или письмо.
        При этом не требуется дополнительное описание - вы просто создадите напоминание с соответствующим
        текстом.
        Если вы укажите описание напоминания - то именно оно и станет текстом напоминания.
        У напоминания должны быть ответственные, если их не указывать - ответственным назначаетесь вы.

        Args:
            body (CreateTaskBody):

        Raises:
            errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
            httpx.TimeoutException: If the request takes longer than Client.timeout.

        Returns:
            Union[CreateTaskResponse201, Errors]
        """
        self.logger.info("Начинаем создание ответа на запрос.")
        kwargs = await self._get_kwargs_createTask(body=body)
        response = await (await self.client.get_async_httpx_client()).request(
            **kwargs
        )
        return (
            await self._build_response_createTask(response=response)
        ).parsed

    async def _get_kwargs_postMessageReactions(
        self, id: int, body: CodeReaction
    ) -> dict[str, Any]:
        headers: dict[str, Any] = {}
        _kwargs: dict[str, Any] = {
            "method": "post",
            "url": f"/messages/{id}/reactions",
        }
        _body = body.to_dict()
        _kwargs["json"] = _body
        headers["Content-Type"] = "application/json"
        _kwargs["headers"] = headers
        self.logger.debug("Создание параметров postMessageReactions.")
        return _kwargs

    async def _parse_response_postMessageReactions(
        self, response: httpx.Response
    ) -> Optional[Union[Any, Errors]]:
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для postMessageReactions"
        )
        if response.status_code == 201:
            response_201 = cast(Any, None)
            return response_201
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для postMessageReactions"
        )
        if response.status_code == 400:
            response_400 = Errors.from_dict(response.json())
            return response_400
        else:
            response_error = Errors.from_dict(response.json())
            return response_error

    async def _build_response_postMessageReactions(
        self, response: httpx.Response
    ) -> Response[Union[Any, Errors]]:
        self.logger.debug(
            "Преобразование JSON в Python для postMessageReactions."
        )
        return Response(
            status_code=HTTPStatus(response.status_code),
            content=response.content,
            headers=response.headers,
            parsed=await self._parse_response_postMessageReactions(
                response=response
            ),
        )

    async def postMessageReactions(
        self, id: int, body: CodeReaction
    ) -> Optional[Union[Any, Errors]]:
        """добавление реакции

         Метод для добавления реакции на сообщение. **Лимиты реакций:** - Каждый пользователь может
        установить не более 20 уникальных реакций на сообщение. - Сообщение может иметь не более 30
        уникальных реакций. - Сообщение может иметь не более 1000 реакций.

        Args:
            id (int):
            body (CodeReaction):

        Raises:
            errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
            httpx.TimeoutException: If the request takes longer than Client.timeout.

        Returns:
            Union[Any, Errors]
        """
        self.logger.info("Начинаем создание ответа на запрос.")
        kwargs = await self._get_kwargs_postMessageReactions(id=id, body=body)
        response = await (await self.client.get_async_httpx_client()).request(
            **kwargs
        )
        return (
            await self._build_response_postMessageReactions(response=response)
        ).parsed

    async def _get_kwargs_getMessageReactions(
        self, id: int, per: Union[Unset, int] = 50, page: Union[Unset, int] = 1
    ) -> dict[str, Any]:
        params: dict[str, Any] = {}
        params["per"] = per
        params["page"] = page
        params = {
            k: v for k, v in params.items() if v is not UNSET and v is not None
        }
        _kwargs: dict[str, Any] = {
            "method": "get",
            "url": f"/messages/{id}/reactions",
            "params": params,
        }
        self.logger.debug("Создание параметров getMessageReactions.")
        return _kwargs

    async def _parse_response_getMessageReactions(
        self, response: httpx.Response
    ) -> Optional[Union[Errors, GetMessageReactionsResponse200]]:
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для getMessageReactions"
        )
        if response.status_code == 200:
            response_200 = GetMessageReactionsResponse200.from_dict(
                response.json()
            )
            return response_200
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для getMessageReactions"
        )
        if response.status_code == 400:
            response_400 = Errors.from_dict(response.json())
            return response_400
        else:
            response_error = Errors.from_dict(response.json())
            return response_error

    async def _build_response_getMessageReactions(
        self, response: httpx.Response
    ) -> Response[Union[Errors, GetMessageReactionsResponse200]]:
        self.logger.debug(
            "Преобразование JSON в Python для getMessageReactions."
        )
        return Response(
            status_code=HTTPStatus(response.status_code),
            content=response.content,
            headers=response.headers,
            parsed=await self._parse_response_getMessageReactions(
                response=response
            ),
        )

    async def getMessageReactions(
        self, id: int, per: Union[Unset, int] = 50, page: Union[Unset, int] = 1
    ) -> Optional[Union[Errors, GetMessageReactionsResponse200]]:
        """получение актуального списка реакций

         Метод для получения актуального списка реакций на сообщение.

        Идентификатор сообщения, список реакций на которое необходимо получить, передается в URL (например,
        /messages/7231942/reactions). Количество возвращаемых сущностей и страница выборки указываются в
        теле запроса

        Args:
            id (int):
            per (Union[Unset, int]):  Default: 50.
            page (Union[Unset, int]):  Default: 1.

        Raises:
            errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
            httpx.TimeoutException: If the request takes longer than Client.timeout.

        Returns:
            Union[Errors, GetMessageReactionsResponse200]
        """
        self.logger.info("Начинаем создание ответа на запрос.")
        kwargs = await self._get_kwargs_getMessageReactions(
            id=id, per=per, page=page
        )
        response = await (await self.client.get_async_httpx_client()).request(
            **kwargs
        )
        return (
            await self._build_response_getMessageReactions(response=response)
        ).parsed

    async def _get_kwargs_deleteMessageReactions(
        self, id: int, code: Union[Unset, str] = UNSET
    ) -> dict[str, Any]:
        params: dict[str, Any] = {}
        params["code"] = code
        params = {
            k: v for k, v in params.items() if v is not UNSET and v is not None
        }
        _kwargs: dict[str, Any] = {
            "method": "delete",
            "url": f"/messages/{id}/reactions",
            "params": params,
        }
        self.logger.debug("Создание параметров deleteMessageReactions.")
        return _kwargs

    async def _parse_response_deleteMessageReactions(
        self, response: httpx.Response
    ) -> Optional[Union[Any, Errors]]:
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для deleteMessageReactions"
        )
        if response.status_code == 204:
            response_204 = cast(Any, None)
            return response_204
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для deleteMessageReactions"
        )
        if response.status_code == 400:
            response_400 = Errors.from_dict(response.json())
            return response_400
        else:
            response_error = Errors.from_dict(response.json())
            return response_error

    async def _build_response_deleteMessageReactions(
        self, response: httpx.Response
    ) -> Response[Union[Any, Errors]]:
        self.logger.debug(
            "Преобразование JSON в Python для deleteMessageReactions."
        )
        return Response(
            status_code=HTTPStatus(response.status_code),
            content=response.content,
            headers=response.headers,
            parsed=await self._parse_response_deleteMessageReactions(
                response=response
            ),
        )

    async def deleteMessageReactions(
        self, id: int, code: Union[Unset, str] = UNSET
    ) -> Optional[Union[Any, Errors]]:
        """удаление реакции

         Метод для удаления реакции на сообщение.  Удалить можно только те реакции, которые были поставлены
        авторизованным пользователем.

        Args:
            id (int):
            code (Union[Unset, str]):  Example: 👍.

        Raises:
            errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
            httpx.TimeoutException: If the request takes longer than Client.timeout.

        Returns:
            Union[Any, Errors]
        """
        self.logger.info("Начинаем создание ответа на запрос.")
        kwargs = await self._get_kwargs_deleteMessageReactions(
            id=id, code=code
        )
        response = await (await self.client.get_async_httpx_client()).request(
            **kwargs
        )
        return (
            await self._build_response_deleteMessageReactions(
                response=response
            )
        ).parsed

    async def _get_kwargs_getEmployees(
        self,
        per: Union[Unset, int] = 50,
        page: Union[Unset, int] = 1,
        query: Union[Unset, str] = UNSET,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {}
        params["per"] = per
        params["page"] = page
        params["query"] = query
        params = {
            k: v for k, v in params.items() if v is not UNSET and v is not None
        }
        _kwargs: dict[str, Any] = {
            "method": "get",
            "url": "/users",
            "params": params,
        }
        self.logger.debug("Создание параметров getEmployees.")
        return _kwargs

    async def _parse_response_getEmployees(
        self, response: httpx.Response
    ) -> Optional[GetEmployeesResponse200]:
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для getEmployees"
        )
        if response.status_code == 200:
            response_200 = GetEmployeesResponse200.from_dict(response.json())
            return response_200
        else:
            response_error = Errors.from_dict(response.json())
            return response_error

    async def _build_response_getEmployees(
        self, response: httpx.Response
    ) -> Response[GetEmployeesResponse200]:
        self.logger.debug("Преобразование JSON в Python для getEmployees.")
        return Response(
            status_code=HTTPStatus(response.status_code),
            content=response.content,
            headers=response.headers,
            parsed=await self._parse_response_getEmployees(response=response),
        )

    async def getEmployees(
        self,
        per: Union[Unset, int] = 50,
        page: Union[Unset, int] = 1,
        query: Union[Unset, str] = UNSET,
    ) -> Optional[GetEmployeesResponse200]:
        """получение актуального списка всех сотрудников компании

         Метод для получения актуального списка сотрудников вашей компании.
        Тело запроса отсутствует, параметры передаются в URL (например,
        /users?per=50&page=2&query=example.com)

        Args:
            per (Union[Unset, int]):  Default: 50.
            page (Union[Unset, int]):  Default: 1.
            query (Union[Unset, str]):

        Raises:
            errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
            httpx.TimeoutException: If the request takes longer than Client.timeout.

        Returns:
            GetEmployeesResponse200
        """
        self.logger.info("Начинаем создание ответа на запрос.")
        kwargs = await self._get_kwargs_getEmployees(
            per=per, page=page, query=query
        )
        response = await (await self.client.get_async_httpx_client()).request(
            **kwargs
        )
        return (
            await self._build_response_getEmployees(response=response)
        ).parsed

    async def _get_kwargs_getEmployee(self, id: int) -> dict[str, Any]:
        _kwargs: dict[str, Any] = {"method": "get", "url": f"/users/{id}"}
        self.logger.debug("Создание параметров getEmployee.")
        return _kwargs

    async def _parse_response_getEmployee(
        self, response: httpx.Response
    ) -> Optional[Union[Errors, GetEmployeeResponse200]]:
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для getEmployee"
        )
        if response.status_code == 200:
            response_200 = GetEmployeeResponse200.from_dict(response.json())
            return response_200
        self.logger.info(
            f"Получен ответ с кодом: {response.status_code} для getEmployee"
        )
        if response.status_code == 400:
            response_400 = Errors.from_dict(response.json())
            return response_400
        else:
            response_error = Errors.from_dict(response.json())
            return response_error

    async def _build_response_getEmployee(
        self, response: httpx.Response
    ) -> Response[Union[Errors, GetEmployeeResponse200]]:
        self.logger.debug("Преобразование JSON в Python для getEmployee.")
        return Response(
            status_code=HTTPStatus(response.status_code),
            content=response.content,
            headers=response.headers,
            parsed=await self._parse_response_getEmployee(response=response),
        )

    async def getEmployee(
        self, id: int
    ) -> Optional[Union[Errors, GetEmployeeResponse200]]:
        """получение информации о сотруднике

         Метод для получения информации о сотруднике.
        Для получения сотрудника вам необходимо знать его id и указать его в URL запроса.

        Args:
            id (int):

        Raises:
            errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
            httpx.TimeoutException: If the request takes longer than Client.timeout.

        Returns:
            Union[Errors, GetEmployeeResponse200]
        """
        self.logger.info("Начинаем создание ответа на запрос.")
        kwargs = await self._get_kwargs_getEmployee(id=id)
        response = await (await self.client.get_async_httpx_client()).request(
            **kwargs
        )
        return (
            await self._build_response_getEmployee(response=response)
        ).parsed
