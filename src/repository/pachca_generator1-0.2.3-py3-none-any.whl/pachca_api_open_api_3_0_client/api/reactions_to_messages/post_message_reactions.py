from http import HTTPStatus
from typing import Any, Optional, Union, cast

import Errors.from_dict
import httpx

from ...models.code_reaction import CodeReaction
from ...models.errors import Errors
from ...types import Response


async def _get_kwargs_postMessageReactions(
    self,
    id: int,
    body: CodeReaction,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": f"/messages/{id}/reactions",
    }

    _body = body.to_dict()

    _kwargs["json"] = _body
    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    self.logger.debug("Создание параметров postMessageReactions.")
    return _kwargs


async def _parse_response_postMessageReactions(self, response: httpx.Response) -> Optional[Union[Any, Errors]]:
    self.logger.info(f"Получен ответ с кодом: {response.status_code} для postMessageReactions")
    if response.status_code == 201:
        response_201 = cast(Any, None)
        return response_201
    self.logger.info(f"Получен ответ с кодом: {response.status_code} для postMessageReactions")
    if response.status_code == 400:
        response_400 = Errors.from_dict(response.json())

        return response_400
    else:
        response_error = Errors.from_dict(response.json())
        return response_error


async def _build_response_postMessageReactions(self, response: httpx.Response) -> Response[Union[Any, Errors]]:
    self.logger.debug("Преобразование JSON в Python для postMessageReactions.")
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=await self._parse_response_postMessageReactions(response=response),
    )


async def postMessageReactions(
    self,
    id: int,
    body: CodeReaction,
) -> Optional[Union[Any, Errors]]:
    """добавление реакции

     Метод для добавления реакции на сообщение. **Лимиты реакций:** - Каждый пользователь может
    установить не более 20 уникальных реакций на сообщение. - Сообщение может иметь не более 30
    уникальных реакций. - Сообщение может иметь не более 1000 реакций.

    Args:
        id (int):
        body (CodeReaction):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, Errors]
    """

    self.logger.info("Начинаем создание ответа на запрос.")

    kwargs = await self._get_kwargs_postMessageReactions(
        id=id,
        body=body,
    )

    response = await (await self.client.get_async_httpx_client()).request(**kwargs)

    return (await self._build_response_postMessageReactions(response=response)).parsed
