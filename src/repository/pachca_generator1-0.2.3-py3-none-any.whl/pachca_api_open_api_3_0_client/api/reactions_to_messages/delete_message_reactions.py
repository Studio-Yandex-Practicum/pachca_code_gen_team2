from http import HTTPStatus
from typing import Any, Optional, Union, cast

import Errors.from_dict
import httpx

from ...models.errors import Errors
from ...types import UNSET, Response, Unset


async def _get_kwargs_deleteMessageReactions(
    self,
    id: int,
    code: Union[Unset, str] = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    params["code"] = code

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": f"/messages/{id}/reactions",
        "params": params,
    }

    self.logger.debug("Создание параметров deleteMessageReactions.")
    return _kwargs


async def _parse_response_deleteMessageReactions(self, response: httpx.Response) -> Optional[Union[Any, Errors]]:
    self.logger.info(f"Получен ответ с кодом: {response.status_code} для deleteMessageReactions")
    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204
    self.logger.info(f"Получен ответ с кодом: {response.status_code} для deleteMessageReactions")
    if response.status_code == 400:
        response_400 = Errors.from_dict(response.json())

        return response_400
    else:
        response_error = Errors.from_dict(response.json())
        return response_error


async def _build_response_deleteMessageReactions(self, response: httpx.Response) -> Response[Union[Any, Errors]]:
    self.logger.debug("Преобразование JSON в Python для deleteMessageReactions.")
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=await self._parse_response_deleteMessageReactions(response=response),
    )


async def deleteMessageReactions(
    self,
    id: int,
    code: Union[Unset, str] = UNSET,
) -> Optional[Union[Any, Errors]]:
    """удаление реакции

     Метод для удаления реакции на сообщение.  Удалить можно только те реакции, которые были поставлены
    авторизованным пользователем.

    Args:
        id (int):
        code (Union[Unset, str]):  Example: 👍.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, Errors]
    """

    self.logger.info("Начинаем создание ответа на запрос.")

    kwargs = await self._get_kwargs_deleteMessageReactions(
        id=id,
        code=code,
    )

    response = await (await self.client.get_async_httpx_client()).request(**kwargs)

    return (await self._build_response_deleteMessageReactions(response=response)).parsed
