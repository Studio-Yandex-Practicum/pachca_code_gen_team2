from http import HTTPStatus
from typing import Any, Optional

import Errors.from_dict
import httpx

from ...types import Response


async def _get_kwargs_delStatus(
    self,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/profile/status",
    }

    self.logger.debug("Создание параметров delStatus.")
    return _kwargs


async def _parse_response_delStatus(self, response: httpx.Response) -> Optional[Any]:
    self.logger.info(f"Получен ответ с кодом: {response.status_code} для delStatus")
    if response.status_code == 204:
        return None
    else:
        response_error = Errors.from_dict(response.json())
        return response_error


async def _build_response_delStatus(self, response: httpx.Response) -> Response[Any]:
    self.logger.debug("Преобразование JSON в Python для delStatus.")
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=await self._parse_response_delStatus(response=response),
    )


async def delStatus(
    self,
) -> Optional[Any]:
    """удаление своего статуса

     Метод для удаления своего статуса. Параметры запроса отсутствуют.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any
    """

    self.logger.info("Начинаем создание ответа на запрос.")

    kwargs = await self._get_kwargs_delStatus()

    response = await (await self.client.get_async_httpx_client()).request(**kwargs)

    return (await self._build_response_delStatus(response=response)).parsed
