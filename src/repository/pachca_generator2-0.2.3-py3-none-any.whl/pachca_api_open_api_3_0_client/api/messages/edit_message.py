from http import HTTPStatus
from typing import Any, Optional, Union

import Errors.from_dict
import httpx

from ...models.edit_message_body import EditMessageBody
from ...models.edit_message_response_200 import EditMessageResponse200
from ...models.errors import Errors
from ...types import Response


async def _get_kwargs_editMessage(
    self,
    id: int,
    body: EditMessageBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": f"/messages/{id}",
    }

    _body = body.to_dict()

    _kwargs["json"] = _body
    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    self.logger.debug("Создание параметров editMessage.")
    return _kwargs


async def _parse_response_editMessage(
    self, response: httpx.Response
) -> Optional[Union[EditMessageResponse200, Errors]]:
    self.logger.info(f"Получен ответ с кодом: {response.status_code} для editMessage")
    if response.status_code == 200:
        response_200 = EditMessageResponse200.from_dict(response.json())

        return response_200
    self.logger.info(f"Получен ответ с кодом: {response.status_code} для editMessage")
    if response.status_code == 400:
        response_400 = Errors.from_dict(response.json())

        return response_400
    else:
        response_error = Errors.from_dict(response.json())
        return response_error


async def _build_response_editMessage(
    self, response: httpx.Response
) -> Response[Union[EditMessageResponse200, Errors]]:
    self.logger.debug("Преобразование JSON в Python для editMessage.")
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=await self._parse_response_editMessage(response=response),
    )


async def editMessage(
    self,
    id: int,
    body: EditMessageBody,
) -> Optional[Union[EditMessageResponse200, Errors]]:
    """редактирование сообщения по указанному идентификатору

     Метод для редактирования сообщения или комментария.

    Args:
        id (int):
        body (EditMessageBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[EditMessageResponse200, Errors]
    """

    self.logger.info("Начинаем создание ответа на запрос.")

    kwargs = await self._get_kwargs_editMessage(
        id=id,
        body=body,
    )

    response = await (await self.client.get_async_httpx_client()).request(**kwargs)

    return (await self._build_response_editMessage(response=response)).parsed
