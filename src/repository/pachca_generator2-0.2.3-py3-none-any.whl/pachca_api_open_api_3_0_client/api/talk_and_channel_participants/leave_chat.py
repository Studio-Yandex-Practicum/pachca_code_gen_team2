from http import HTTPStatus
from typing import Any, Optional, Union, cast

import Errors.from_dict
import httpx

from ...models.errors import Errors
from ...types import Response


async def _get_kwargs_leaveChat(
    self,
    id: int,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": f"/chats/{id}/leave",
    }

    self.logger.debug("Создание параметров leaveChat.")
    return _kwargs


async def _parse_response_leaveChat(self, response: httpx.Response) -> Optional[Union[Any, Errors]]:
    self.logger.info(f"Получен ответ с кодом: {response.status_code} для leaveChat")
    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204
    self.logger.info(f"Получен ответ с кодом: {response.status_code} для leaveChat")
    if response.status_code == 400:
        response_400 = Errors.from_dict(response.json())

        return response_400
    else:
        response_error = Errors.from_dict(response.json())
        return response_error


async def _build_response_leaveChat(self, response: httpx.Response) -> Response[Union[Any, Errors]]:
    self.logger.debug("Преобразование JSON в Python для leaveChat.")
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=await self._parse_response_leaveChat(response=response),
    )


async def leaveChat(
    self,
    id: int,
) -> Optional[Union[Any, Errors]]:
    """выход из беседы или канала

     Метод для самостоятельного выхода из беседы или канала. Параметры запроса отсутствуют/

    Args:
        id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, Errors]
    """

    self.logger.info("Начинаем создание ответа на запрос.")

    kwargs = await self._get_kwargs_leaveChat(
        id=id,
    )

    response = await (await self.client.get_async_httpx_client()).request(**kwargs)

    return (await self._build_response_leaveChat(response=response)).parsed
