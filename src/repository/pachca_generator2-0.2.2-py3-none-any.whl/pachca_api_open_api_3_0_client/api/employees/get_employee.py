from http import HTTPStatus
from typing import Any, Optional, Union

import Errors.from_dict
import httpx

from ...models.errors import Errors
from ...models.get_employee_response_200 import GetEmployeeResponse200
from ...types import Response


async def _get_kwargs_getEmployee(
    self,
    id: int,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": f"/users/{id}",
    }

    self.logger.debug("Создание параметров getEmployee.")
    return _kwargs


async def _parse_response_getEmployee(
    self, response: httpx.Response
) -> Optional[Union[Errors, GetEmployeeResponse200]]:
    self.logger.info(f"Получен ответ с кодом: {response.status_code} для getEmployee")
    if response.status_code == 200:
        response_200 = GetEmployeeResponse200.from_dict(response.json())

        return response_200
    self.logger.info(f"Получен ответ с кодом: {response.status_code} для getEmployee")
    if response.status_code == 400:
        response_400 = Errors.from_dict(response.json())

        return response_400
    else:
        response_error = Errors.from_dict(response.json())
        return response_error


async def _build_response_getEmployee(
    self, response: httpx.Response
) -> Response[Union[Errors, GetEmployeeResponse200]]:
    self.logger.debug("Преобразование JSON в Python для getEmployee.")
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=await self._parse_response_getEmployee(response=response),
    )


async def getEmployee(
    self,
    id: int,
) -> Optional[Union[Errors, GetEmployeeResponse200]]:
    """получение информации о сотруднике

     Метод для получения информации о сотруднике.
    Для получения сотрудника вам необходимо знать его id и указать его в URL запроса.

    Args:
        id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Errors, GetEmployeeResponse200]
    """

    self.logger.info("Начинаем создание ответа на запрос.")

    kwargs = await self._get_kwargs_getEmployee(
        id=id,
    )

    response = await (await self.client.get_async_httpx_client()).request(**kwargs)

    return (await self._build_response_getEmployee(response=response)).parsed
