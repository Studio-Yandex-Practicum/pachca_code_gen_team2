import datetime
from http import HTTPStatus
from typing import Any, Optional, Union

import Errors.from_dict
import httpx

from ...models.errors import Errors
from ...models.get_chats_availability import GetChatsAvailability
from ...models.get_chats_response_200 import GetChatsResponse200
from ...models.get_chats_sortid import GetChatsSortid
from ...types import UNSET, Response, Unset


async def _get_kwargs_getChats(
    self,
    sortid: Union[Unset, GetChatsSortid] = GetChatsSortid.DESC,
    per: Union[Unset, int] = 25,
    page: Union[Unset, int] = 1,
    availability: Union[Unset, GetChatsAvailability] = GetChatsAvailability.IS_MEMBER,
    last_message_at_after: Union[Unset, datetime.datetime] = UNSET,
    last_message_at_before: Union[Unset, datetime.datetime] = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    json_sortid: Union[Unset, str] = UNSET
    if not isinstance(sortid, Unset):
        json_sortid = sortid.value

    params["sort[id]"] = json_sortid

    params["per"] = per

    params["page"] = page

    json_availability: Union[Unset, str] = UNSET
    if not isinstance(availability, Unset):
        json_availability = availability.value

    params["availability"] = json_availability

    json_last_message_at_after: Union[Unset, str] = UNSET
    if not isinstance(last_message_at_after, Unset):
        json_last_message_at_after = last_message_at_after.isoformat()
    params["last_message_at_after"] = json_last_message_at_after

    json_last_message_at_before: Union[Unset, str] = UNSET
    if not isinstance(last_message_at_before, Unset):
        json_last_message_at_before = last_message_at_before.isoformat()
    params["last_message_at_before"] = json_last_message_at_before

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/chats",
        "params": params,
    }

    self.logger.debug("Создание параметров getChats.")
    return _kwargs


async def _parse_response_getChats(self, response: httpx.Response) -> Optional[Union[Errors, GetChatsResponse200]]:
    self.logger.info(f"Получен ответ с кодом: {response.status_code} для getChats")
    if response.status_code == 200:
        response_200 = GetChatsResponse200.from_dict(response.json())

        return response_200
    self.logger.info(f"Получен ответ с кодом: {response.status_code} для getChats")
    if response.status_code == 400:
        response_400 = Errors.from_dict(response.json())

        return response_400
    self.logger.info(f"Получен ответ с кодом: {response.status_code} для getChats")
    if response.status_code == 422:
        response_422 = Errors.from_dict(response.json())

        return response_422
    else:
        response_error = Errors.from_dict(response.json())
        return response_error


async def _build_response_getChats(self, response: httpx.Response) -> Response[Union[Errors, GetChatsResponse200]]:
    self.logger.debug("Преобразование JSON в Python для getChats.")
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=await self._parse_response_getChats(response=response),
    )


async def getChats(
    self,
    sortid: Union[Unset, GetChatsSortid] = GetChatsSortid.DESC,
    per: Union[Unset, int] = 25,
    page: Union[Unset, int] = 1,
    availability: Union[Unset, GetChatsAvailability] = GetChatsAvailability.IS_MEMBER,
    last_message_at_after: Union[Unset, datetime.datetime] = UNSET,
    last_message_at_before: Union[Unset, datetime.datetime] = UNSET,
) -> Optional[Union[Errors, GetChatsResponse200]]:
    """получение списка бесед и каналов

     Метод для получения списка бесед и каналов по заданным параметрам.

    Тело запроса отсутствует, параметры передаются в URL (например, /chats?per=2&sort[id]=desc)

    Args:
        sortid (Union[Unset, GetChatsSortid]):  Default: GetChatsSortid.DESC.
        per (Union[Unset, int]):  Default: 25.
        page (Union[Unset, int]):  Default: 1.
        availability (Union[Unset, GetChatsAvailability]):  Default:
            GetChatsAvailability.IS_MEMBER.
        last_message_at_after (Union[Unset, datetime.datetime]):
        last_message_at_before (Union[Unset, datetime.datetime]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Errors, GetChatsResponse200]
    """

    self.logger.info("Начинаем создание ответа на запрос.")

    kwargs = await self._get_kwargs_getChats(
        sortid=sortid,
        per=per,
        page=page,
        availability=availability,
        last_message_at_after=last_message_at_after,
        last_message_at_before=last_message_at_before,
    )

    response = await (await self.client.get_async_httpx_client()).request(**kwargs)

    return (await self._build_response_getChats(response=response)).parsed
