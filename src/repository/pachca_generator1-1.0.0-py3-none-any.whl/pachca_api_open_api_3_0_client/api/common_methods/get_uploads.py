from http import HTTPStatus
from typing import Any, Optional

import Errors.from_dict
import httpx

from ...models.file_response import FileResponse
from ...types import Response


def _get_kwargs_getUploads(
    self,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/uploads",
    }

    self.logger.debug("Создание параметров getUploads.")
    return _kwargs


def _parse_response_getUploads(self, response: httpx.Response) -> Optional[FileResponse]:
    self.logger.info(f"Получен ответ с кодом: {response.status_code} для getUploads")
    if response.status_code == 200:
        response_200 = FileResponse.from_dict(response.json())

        return response_200
    else:
        response_error = Errors.from_dict(response.json())
        return response_error


def _build_response_getUploads(self, response: httpx.Response) -> Response[FileResponse]:
    self.logger.debug("Преобразование JSON в Python для getUploads.")
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=self._parse_response_getUploads(response=response),
    )


async def getUploads(
    self,
) -> Optional[FileResponse]:
    """получения подписи и ключа для загрузки файла

     Данный метод необходимо использовать для загрузки каждого файла.

    Данный метод позволяет получить уникальный набор параметров для загрузки файла. Параметры запроса
    отсутствуют.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FileResponse
    """

    self.logger.info("Начинаем создание ответа на запрос.")

    kwargs = self._get_kwargs_getUploads()

    response = await self.client.get_async_httpx_client().request(**kwargs)

    return self._build_response_getUploads(response=response).parsed
