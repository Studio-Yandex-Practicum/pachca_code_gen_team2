from http import HTTPStatus
from typing import Any, Optional, Union

import Errors.from_dict
import httpx

from ...models.get_employees_response_200 import GetEmployeesResponse200
from ...types import UNSET, Response, Unset


def _get_kwargs_getEmployees(
    self,
    per: Union[Unset, int] = 50,
    page: Union[Unset, int] = 1,
    query: Union[Unset, str] = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    params["per"] = per

    params["page"] = page

    params["query"] = query

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/users",
        "params": params,
    }

    self.logger.debug("Создание параметров getEmployees.")
    return _kwargs


def _parse_response_getEmployees(self, response: httpx.Response) -> Optional[GetEmployeesResponse200]:
    self.logger.info(f"Получен ответ с кодом: {response.status_code} для getEmployees")
    if response.status_code == 200:
        response_200 = GetEmployeesResponse200.from_dict(response.json())

        return response_200
    else:
        response_error = Errors.from_dict(response.json())
        return response_error


def _build_response_getEmployees(self, response: httpx.Response) -> Response[GetEmployeesResponse200]:
    self.logger.debug("Преобразование JSON в Python для getEmployees.")
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=self._parse_response_getEmployees(response=response),
    )


async def getEmployees(
    self,
    per: Union[Unset, int] = 50,
    page: Union[Unset, int] = 1,
    query: Union[Unset, str] = UNSET,
) -> Optional[GetEmployeesResponse200]:
    """получение актуального списка всех сотрудников компании

     Метод для получения актуального списка сотрудников вашей компании.
    Тело запроса отсутствует, параметры передаются в URL (например,
    /users?per=50&page=2&query=example.com)

    Args:
        per (Union[Unset, int]):  Default: 50.
        page (Union[Unset, int]):  Default: 1.
        query (Union[Unset, str]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetEmployeesResponse200
    """

    self.logger.info("Начинаем создание ответа на запрос.")

    kwargs = self._get_kwargs_getEmployees(
        per=per,
        page=page,
        query=query,
    )

    response = await self.client.get_async_httpx_client().request(**kwargs)

    return self._build_response_getEmployees(response=response).parsed
