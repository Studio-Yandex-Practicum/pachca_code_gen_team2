from typing import Any, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.custom_properties_item_data_type import CustomPropertiesItemDataType
from ..types import UNSET, Unset

T = TypeVar("T", bound="CustomPropertiesItem")


@_attrs_define
class CustomPropertiesItem:
    """
    Attributes:
        id (Union[Unset, int]): Идентификатор поля
        value (Union[Unset, str]): Значение поля
        name (Union[Unset, str]): Название поля
        data_type (Union[Unset, CustomPropertiesItemDataType]): Тип поля (string, number, date или link)
    """

    id: Union[Unset, int] = UNSET
    value: Union[Unset, str] = UNSET
    name: Union[Unset, str] = UNSET
    data_type: Union[Unset, CustomPropertiesItemDataType] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        value = self.value

        name = self.name

        data_type: Union[Unset, str] = UNSET
        if not isinstance(self.data_type, Unset):
            data_type = self.data_type.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if value is not UNSET:
            field_dict["value"] = value
        if name is not UNSET:
            field_dict["name"] = name
        if data_type is not UNSET:
            field_dict["data_type"] = data_type

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: dict[str, Any]) -> T:
        d = src_dict.copy()
        id = d.pop("id", UNSET)

        value = d.pop("value", UNSET)

        name = d.pop("name", UNSET)

        _data_type = d.pop("data_type", UNSET)
        data_type: Union[Unset, CustomPropertiesItemDataType]
        if isinstance(_data_type, Unset):
            data_type = UNSET
        else:
            data_type = CustomPropertiesItemDataType(_data_type)

        custom_properties_item = cls(
            id=id,
            value=value,
            name=name,
            data_type=data_type,
        )

        custom_properties_item.additional_properties = d
        return custom_properties_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
